SET enable_locality_backfill = true;
SET locality_backfill_mode = always;
SET streaming_parallelism = 4;
SET streaming_use_snapshot_backfill = true;
SET enable_locality_sort_buffer = false;
SET background_ddl = false;
CREATE MATERIALIZED VIEW tpch_q18 AS
select
  c_name,
  c_custkey,
  o_orderkey,
  o_orderdate,
  o_totalprice,
  sum(l_quantity) quantity
from
  customer,
  orders,
  lineitem
where
  o_orderkey in (
    select
      l_orderkey
    from
      lineitem
    group by
      l_orderkey having
        sum(l_quantity) > 1
  )
  and c_custkey = o_custkey
  and o_orderkey = l_orderkey
group by
  c_name,
  c_custkey,
  o_orderkey,
  o_orderdate,
  o_totalprice
order by
  o_totalprice desc,
  o_orderdate
LIMIT 100;

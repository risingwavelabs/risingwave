#!/usr/bin/env python3
"""Run a local RiseDev full test with a shared host lease."""
import fcntl
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

PREFLIGHT_POLL_SECONDS = 5
QUIET_SECONDS = 60
RUN_POLL_SECONDS = 2
PORTS = (4566, 1222, 5688, 9301, 8432, 8181, 29092, 29094)
FULL_CONTAINERS = {"risedev-postgres-8432", "risedev-kafka-29092"}
FULL_PROCESSES = {"risingwave", "risedev-dev"}
TEST_PROCESSES = {"cargo", "cargo-make", "rustc", "sqllogictest", "nexmark", "nexmark-bench"}


def run_check(args):
    return subprocess.run(args, capture_output=True, text=True, timeout=5)


def docker_blockers(allowed):
    containers = run_check(["docker", "ps", "--format", "{{.Names}}"])
    if containers.returncode != 0:
        return ["Docker state unavailable"]
    foreign = sorted(set(containers.stdout.splitlines()) - allowed)
    return ["Docker: " + ", ".join(foreign)] if foreign else []


def process_blockers(owned_group):
    processes = run_check(["ps", "-A", "-o", "pgid=,comm="])
    if processes.returncode != 0:
        return ["Process state unavailable"]
    expected = TEST_PROCESSES if owned_group else TEST_PROCESSES | FULL_PROCESSES
    names = set()
    for line in processes.stdout.splitlines():
        group, executable = line.strip().split(maxsplit=1)
        if int(group) != owned_group:
            names.add(Path(executable).name)
    tests = sorted(names & expected)
    return ["Processes: " + ", ".join(tests)] if tests else []


def preflight_blockers():
    blockers = docker_blockers(set()) + process_blockers(None)
    if run_check(["tmux", "-L", "risedev", "ls"]).returncode == 0:
        blockers.append("RiseDev tmux is active")
    listeners = run_check([
        "lsof", "-nP", "-a", *(f"-iTCP:{port}" for port in PORTS), "-sTCP:LISTEN",
    ])
    if listeners.returncode == 0:
        blockers.append("RiseDev ports have listeners")
    elif listeners.returncode != 1:
        blockers.append("RiseDev port state unavailable")
    return blockers


def check_blockers(check):
    try:
        return check()
    except (OSError, subprocess.TimeoutExpired) as error:
        return [f"Test state unavailable: {error}"]


def wait_for_quiet():
    idle_since = None
    previous = None
    while True:
        blockers = check_blockers(preflight_blockers)
        if blockers:
            idle_since = None
            if blockers != previous:
                print("Waiting for local tests: " + " | ".join(blockers), flush=True)
        else:
            now = time.monotonic()
            if idle_since is None:
                idle_since = now
                print(f"Waiting for {QUIET_SECONDS}s of continuous idle time", flush=True)
            if now - idle_since >= QUIET_SECONDS:
                return
        previous = blockers
        time.sleep(PREFLIGHT_POLL_SECONDS)


def stop_owned_command(process):
    if process.poll() is None:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    return process.wait()


def run_guarded(command):
    process = subprocess.Popen(command, start_new_session=True)
    try:
        while process.poll() is None:
            blockers = check_blockers(
                lambda: docker_blockers(FULL_CONTAINERS) + process_blockers(process.pid)
            )
            if blockers:
                print("Stopping owned test because another test started: " + " | ".join(blockers), flush=True)
                stop_owned_command(process)
                return 75
            time.sleep(RUN_POLL_SECONDS)
        return process.returncode
    finally:
        stop_owned_command(process)


def main(command):
    lock_path = Path("/tmp") / f"risingwave-local-test-{os.getuid()}.lock"
    with lock_path.open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print(f"Waiting for shared test lock {lock_path}", flush=True)
            fcntl.flock(lock, fcntl.LOCK_EX)
        wait_for_quiet()
        print(f"Local test guard acquired {lock_path}", flush=True)
        return run_guarded(command)


def terminate(_signal, _frame):
    raise SystemExit(143)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit(f"usage: {sys.argv[0]} COMMAND [ARG ...]")
    signal.signal(signal.SIGTERM, terminate)
    raise SystemExit(main(sys.argv[1:]))

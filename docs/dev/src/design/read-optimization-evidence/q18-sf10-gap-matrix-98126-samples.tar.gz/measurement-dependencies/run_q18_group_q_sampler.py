"""TPC-H SF1 Q18 Locality Backfill; run only under the shared host guard."""
from pathlib import Path
from decimal import Decimal
import csv, gzip, importlib.util, json, os, re, shutil, signal, subprocess, sys, time
from urllib.request import urlopen
import threading

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
SRC = ROOT / 'runtime-q64-prep-trim-src'
RUNTIME = SRC / '.risingwave'
BINARY = REPO / 'target/locality-tpch-q18/q64-prep-trim-bin/risingwave'
ENV = os.environ | {'USE_SYSTEM_RISINGWAVE':'true','TERM':'xterm','PGCONNECT_TIMEOUT':'3','RUST_LOG':'info','PATH':str(BINARY.parent)+os.pathsep+os.environ['PATH']}
SQL = ['psql','-X','-w','-h','127.0.0.1','-p','4566','-U','root','-d','dev','-v','ON_ERROR_STOP=1','-At']
PROFILE = (SRC/'risedev.yml').read_text()
spec=importlib.util.spec_from_file_location('local_guard', REPO/'target/risingwave-local-test-guard.py')
guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
active = False
jobs = []
current = ROOT

def command(args, log, timeout=240):
    with log.open('w') as out:
        subprocess.run(args,cwd=SRC,env=ENV,stdout=out,stderr=subprocess.STDOUT,check=True,timeout=timeout)

def sql(statement, log, timeout=120):
    r=subprocess.run(SQL,cwd=SRC,env=ENV,input=statement+'\n',capture_output=True,text=True,timeout=timeout)
    log.write_text(r.stdout+r.stderr)
    if r.returncode: raise RuntimeError(f'SQL failure: {log}')
    return r.stdout.strip()

def scrape():
    with urlopen('http://127.0.0.1:1222/metrics',timeout=5) as f: return f.read()

def statements(path):
    chunks=path.read_text().split('statement ok\n')[1:]
    return '\n'.join(c.split('\n\n')[0].strip() for c in chunks)

def stop():
    global active
    for p in jobs:
        if p.poll() is None: p.terminate()
    for p in jobs:
        try: p.wait(timeout=10)
        except subprocess.TimeoutExpired: p.kill();p.wait()
    jobs.clear()
    if active:
        # RiseDev k stops globally named containers. Prove pane ownership and stop
        # only the two known full-profile containers instead of using that broad kill.
        panes=subprocess.run(['tmux','-L','risedev','list-panes','-a','-F','#{pane_id} #{pane_current_path}'],capture_output=True,text=True)
        if panes.returncode==0:
            lines=[line.split(' ',1) for line in panes.stdout.splitlines()]
            assert all(Path(path).is_relative_to(SRC) for _,path in lines), panes.stdout
            containers=subprocess.check_output(['docker','ps','--format','{{.ID}} {{.Names}}'],text=True).splitlines()
            owned=[]
            for line in containers:
                ident,name=line.split()
                if name in guard.FULL_CONTAINERS:
                    # These names did not exist at the guarded pre-start check;
                    # the still-owned tmux session launched them.
                    owned.append(ident)
            (current/'cleanup-ownership.json').write_text(json.dumps({'panes':lines,'containers':owned}))
            for pane,_ in lines:
                subprocess.run(['tmux','-L','risedev','send-keys','-t',pane,'C-c'],check=True)
            if owned: command(['docker','stop',*owned],current/'stop-containers.log',60)
            subprocess.run(['tmux','-L','risedev','kill-server'],check=True)
        deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            remaining=guard.preflight_blockers()
            if not remaining:break
            time.sleep(.2)
        else:raise RuntimeError(f'Resources remain after owned cleanup; preserving data: {remaining}')
        assert not subprocess.check_output(['docker','ps','-q'],text=True).strip(), 'Containers remain; preserving data'
        (current/'cleanup.txt').write_text('Owned panes stopped; full-service listeners and containers absent.\n')
        active=False


DATASET = json.loads((ROOT / 'dataset.json').read_text())
TABLES = tuple(DATASET['rows'])
QUERY = (ROOT / 'query-select.sql').read_text()
DDL = 'CREATE MATERIALIZED VIEW tpch_q18 AS\n' + QUERY
SEED = ROOT / 'seed-image'
STORED_DIRS = ('minio', 'postgres-8432')
SETUP = """SET locality_backfill_mode = always;
SET streaming_parallelism = 4;
SET streaming_use_snapshot_backfill = true;
SET enable_locality_sort_buffer = false;
SET background_ddl = false;
"""
CONFIG = """[server]
metrics_level = "Debug"

[frontend]
unsafe_enable_local_fs_connector = true

[streaming]
unsafe_disable_strict_consistency = true

[storage.blockwise_prefetch]
enabled = false
locality_backfill_enabled = false

[storage.object_store]
enable_hummock_read_coalescing = false
"""

def arm_config(name):
    if name not in ('on-optimized', 'on-aligned', 'on-gap-trace'):
        return CONFIG
    config = (CONFIG.replace('enabled = false', 'enabled = true')
              .replace('enable_hummock_read_coalescing = false', 'enable_hummock_read_coalescing = true'))
    if name in ('on-aligned', 'on-gap-trace'):
        config = config.replace('locality_backfill_enabled = true\n', """locality_backfill_enabled = true
max_blocks = 16
max_bytes = 1048576
""")
        config += "\n[storage.object_store.read_scheduler]\nmax_read_bytes = 1048576\n"
    return config


def start(name):
    global active, current
    current = ROOT / name
    current.mkdir()
    config = current / 'risingwave.toml'
    effective_config = arm_config(name)
    config.write_text(effective_config)
    begin, end = PROFILE.split('  full:\n    steps:\n', 1)
    original = '      - use: compute-node\n      - use: frontend\n'
    override = '      - use: compute-node\n        total-memory-bytes: 2147483648\n        async-stack-trace: "off"\n      - use: frontend\n'
    assert end.index(original) < end.index('  standalone-full-peripherals:')
    (SRC / 'risedev.yml').write_text(begin + f'  full:\n    config-path: {config}\n    steps:\n' + end.replace(original, override, 1))
    assert not guard.preflight_blockers()
    active = True
    previous_log = ENV['RUST_LOG']
    if name == 'on-gap-trace':
        ENV['RUST_LOG'] += ',state_store_read_batch=debug,object_store_read_scheduler=debug'
    try:
        command(['./risedev', 'd', 'full'], current / 'start.log', 240)
    finally:
        ENV['RUST_LOG'] = previous_log
    assert (RUNTIME / 'config/risingwave.toml').read_text() == effective_config
    expanded = RUNTIME / 'config/risedev-expanded.yml'
    shutil.copy2(expanded, current / 'expanded.yml')
    assert 'total-memory-bytes: 2147483648' in expanded.read_text()
    startup = (RUNTIME / 'log/compute-node-5688.log').read_text()
    assert 'unsafe_disable_strict_consistency: true' in startup
    assert 'Using OpenDAL to access minio' in startup
    pid = subprocess.check_output(['lsof','-nP','-t','-iTCP:5688','-sTCP:LISTEN'], text=True).strip()
    executable = subprocess.check_output(['lsof','-nP','-a','-p',pid,'-d','txt','-Fn'], text=True)
    assert 'n' + str(BINARY) in executable.splitlines()
    (current / 'executable.txt').write_text(executable)
    print(f'{name}: full started, CN pid={pid}', flush=True)
    return pid

def close():
    stop()
    if not (current / 'logs').exists():
        shutil.copytree(RUNTIME / 'log', current / 'logs')

def table_counts():
    statement = ' UNION ALL '.join(f"SELECT '{table}', count(*) FROM {table}" for table in TABLES) + ';'
    result = sql(statement, current / 'table-counts.txt', 100)
    return {name: int(n) for name, n in csv.reader(result.splitlines(), delimiter='|')}

def seed():
    assert not (RUNTIME / 'data').exists()
    start('seed')
    definitions = statements(REPO / 'e2e_test/tpch/create_tables.slt.part')
    create = ['SET streaming_parallelism = 4;']
    for table in TABLES:
        ddl = re.search(rf'CREATE TABLE {table} \(.*?\n\);', definitions, re.S).group(0)
        directory = ROOT / 'data' / table
        create.append(ddl[:-1] + f"""
WITH (connector = 'posix_fs', posix_fs.root = '{directory}')
FORMAT PLAIN ENCODE CSV (without_header = 'true', delimiter = ',');
""")
    (current / 'load.sql').write_text('\n'.join(create) + '\n')
    sql('\n'.join(create), current / 'load.txt', 180)
    print('seed: loading SF1 files', flush=True)
    deadline = time.monotonic() + 900
    while time.monotonic() < deadline:
        counts = table_counts()
        with (current / 'load-progress.jsonl').open('a') as progress:
            print(json.dumps(counts), file=progress)
        assert all(counts[table] <= DATASET['rows'][table] for table in TABLES), counts
        if counts == DATASET['rows']:
            break
        time.sleep(15)
    else:
        raise TimeoutError(f'incomplete SF1 load: {counts}')
    detach = '\n'.join(f'ALTER TABLE {table} DROP CONNECTOR;' for table in TABLES)
    sql(detach + '\nFLUSH;', current / 'detach.txt', 180)
    assert table_counts() == DATASET['rows']
    sql("SELECT id, name FROM rw_catalog.rw_tables WHERE name IN ('customer','orders','lineitem') ORDER BY id;", current / 'base-table-ids.txt')
    sql('FLUSH;', current / 'flush.txt')
    print('seed: all rows verified and file connectors detached', flush=True)
    close()
    SEED.mkdir()
    for directory in STORED_DIRS:
        command(['cp', '-cR', str(RUNTIME/'data'/directory), str(SEED/directory)], current / f'clone-{directory}.log', 120)
    shutil.rmtree(RUNTIME / 'data')

metric_re = re.compile(r'^([a-zA-Z_:][a-zA-Z_0-9:]*)(\{.*\})? ([-+0-9.eE]+)$')

def metrics(raw):
    out = {}
    for line in raw.decode().splitlines():
        if m := metric_re.match(line):
            out[m[1], tuple(sorted(re.findall(r'(\w+)="([^"]*)"', m[2] or '')))] = float(m[3])
    return out

def delta(before, after, name, **labels):
    return sum(value - before.get((metric, series), 0)
               for (metric, series), value in after.items()
               if metric == name and labels.items() <= dict(series).items())

PREFIXES = ('object_store_operation_', 'object_store_read_scheduler_',
            'object_store_read_requests', 'state_store_blockwise_prefetch_', 'state_store_sst_store_block_request_counts',
            'state_store_iter_scan_key_counts', 'stream_join_lookup_', 'stream_agg_',
            'stream_snapshot_backfill_consume_snapshot_row_count', 'stream_backfill_',
            'process_cpu_seconds_total', 'process_resident_memory_bytes',
            'stream_barrier_inflight_duration_seconds')

def collect(elapsed, pid):
    raw = scrape()
    selected = [line for line in raw.decode().splitlines()
                if line.startswith(PREFIXES) and '_bucket{' not in line]
    rss = subprocess.check_output(['ps','-p',pid,'-o','rss='],text=True).strip()
    return [round(elapsed, 3), int(rss), selected]

def check_output():
    actual = sql('SELECT c_name, c_custkey, o_orderkey, o_orderdate, o_totalprice, quantity FROM tpch_q18;', current / 'oracle.txt')
    expected = json.loads((ROOT / 'expected.json').read_text())
    def normalize(row):
        return (row[0], int(row[1]), int(row[2]), row[3], Decimal(row[4]), Decimal(row[5]))
    assert sorted(map(normalize, csv.reader(actual.splitlines(), delimiter='|'))) == sorted(map(normalize, expected))


def sample_startup(t0, output):
    prefixes = tuple('object_store_read_scheduler_' + key for key in (
        'waiting{', 'pending{', 'preparing{', 'queued{', 'in_flight{', 'groups{',
        'events{', 'admission_duration_seconds_', 'queue_duration_seconds_',
    ))
    prefixes += (
        'object_store_operation_latency_count{',
        'object_store_read_scheduler_overread_bytes{',
        'state_store_blockwise_prefetch_wait_duration_seconds_',
        'state_store_blockwise_prefetch_events{',
        'process_resident_memory_bytes ',
    )
    origin = time.monotonic()
    with output.open('w') as out:
        for sample_no in range(180):
            due = origin + 0.04 * sample_no
            time.sleep(max(0, due - time.monotonic()))
            started = time.monotonic()
            if started - t0 >= 5.10:
                break
            if started - due >= 0.04:
                continue
            try:
                raw = scrape()
            except Exception as exc:
                print(json.dumps([started - t0, time.monotonic() - t0, str(exc)]), file=out)
                continue
            ended = time.monotonic()
            selected = [line for line in raw.decode().splitlines() if line.startswith(prefixes)]
            print(json.dumps([started - t0, ended - t0, selected]), file=out)


def arm(name, locality):
    assert not (RUNTIME / 'data').exists()
    (RUNTIME / 'data').mkdir()
    for directory in STORED_DIRS:
        subprocess.run(['cp','-cR',str(SEED/directory),str(RUNTIME/'data'/directory)], check=True, timeout=120)
    pid = start(name)
    for enabled in (False, True):
        settings = f'SET enable_locality_backfill = {str(enabled).lower()};\n' + SETUP
        plan = sql(settings + 'EXPLAIN ' + DDL, current / f'plan-{enabled}.txt')
        assert 'StreamHashJoin' in plan and 'StreamHashAgg' in plan
        assert ('StreamLocalityProvider' in plan) == enabled, plan
    settings = f'SET enable_locality_backfill = {str(locality).lower()};\n' + SETUP
    (current / 'query.sql').write_text(settings + DDL)
    before = scrape()
    (current / 'before.prom').write_bytes(before)
    t0 = time.monotonic()
    print(f'{name}: starting Q18', flush=True)
    completed = False
    next_jobs = 15
    peak = metrics(before)
    with (current / 'ddl.txt').open('w') as out, gzip.open(current / 'samples.jsonl.gz','wt') as samples:
        job = subprocess.Popen(SQL + ['-f', str(current / 'query.sql')], cwd=SRC, env=ENV,
                               stdout=out, stderr=subprocess.STDOUT)
        jobs.append(job)
        threading.Thread(target=sample_startup, args=(t0, current / 'startup-samples.jsonl'),
                         daemon=True).start()
        while job.poll() is None:
            try:
                job.wait(timeout=5)
            except subprocess.TimeoutExpired:
                elapsed = time.monotonic() - t0
                sample = collect(elapsed, pid)
                print(json.dumps(sample), file=samples)
                samples.flush()
                for series,value in metrics('\n'.join(sample[2]).encode()).items():
                    peak[series] = max(value, peak.get(series, 0))
                if elapsed >= next_jobs:
                    progress = sql('SHOW JOBS;', current / 'jobs-latest.txt', 10)
                    with (current / 'jobs.jsonl').open('a') as log:
                        print(json.dumps([round(elapsed,3), progress]), file=log)
                    next_jobs += 15
        if job.poll() is not None:
            assert job.returncode == 0, current/'ddl.txt'
            completed = True
    elapsed = time.monotonic() - t0
    after = scrape()
    (current / 'after.prom').write_bytes(after)
    b, a = metrics(before), metrics(after)
    for series,value in a.items():
        peak[series] = max(value, peak.get(series, 0))
    get = lambda metric, **labels: delta(b, a, metric, **labels)
    retained = lambda metric, **labels: delta(b, peak, metric, **labels)
    result = dict(arm=name, locality=locality, completed=completed, seconds=elapsed,
                  cn_gets=get('object_store_operation_bytes_count', type='read'),
                  cn_read_gib=get('object_store_operation_bytes_sum', type='read')/2**30,
                  cn_cpu_s=get('process_cpu_seconds_total'),
                  join_lookups=retained('stream_join_lookup_total_count'),
                  join_misses=retained('stream_join_lookup_miss_count'),
                  block_lookups=retained('state_store_sst_store_block_request_counts',type='data_total'),
                  block_misses=retained('state_store_sst_store_block_request_counts',type='data_miss'))
    if completed:
        check_output()
    (current / 'result.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)
    close()
    shutil.rmtree(RUNTIME / 'data')

def terminate(*_):
    raise SystemExit(143)

if __name__ == '__main__':
    signal.signal(signal.SIGTERM, terminate)
    assert subprocess.check_output(['shasum','-a','256',str(BINARY)],text=True).split()[0] == (ROOT/'q64-prep-trim-bin/binary.sha256').read_text().split()[0]
    try:
        for name in sys.argv[1:]:
            if name == 'seed':
                seed()
            else:
                assert name in ('on', 'off', 'on-optimized', 'on-aligned', 'on-gap-trace')
                arm(name, name != 'off')
    finally:
        try:
            stop()
        finally:
            if (RUNTIME/'log').exists() and current != ROOT and not (current/'logs').exists():
                shutil.copytree(RUNTIME/'log',current/'logs')
            (SRC/'risedev.yml').write_text(PROFILE)

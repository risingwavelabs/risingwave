"""Pure parser extracted unchanged from the measurement helper for offline analysis."""
import re

metric_re = re.compile(r'^([a-zA-Z_:][a-zA-Z_0-9:]*)(\{.*\})? ([-+0-9.eE]+)$')

def metrics(raw):
    out = {}
    for line in raw.decode().splitlines():
        if m := metric_re.match(line):
            out[m[1], tuple(sorted(re.findall(r'(\w+)="([^"]*)"', m[2] or '')))] = float(m[3])
    return out

def delta(before, after, name, **labels):
    return sum(value - before.get((metric, series), 0)
               for (metric, series), value in after.items()
               if metric == name and labels.items() <= dict(series).items())

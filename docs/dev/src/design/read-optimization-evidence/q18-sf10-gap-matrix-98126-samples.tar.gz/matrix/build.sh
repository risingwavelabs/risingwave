#!/usr/bin/env bash
set -euo pipefail
suite="$1"
base_repo="$2"
cd "$(cat "$suite/source-worktree.txt")"
export CARGO_TARGET_DIR
CARGO_TARGET_DIR=$(cat "$suite/build-target.txt")
mkdir "$CARGO_TARGET_DIR"
cp -cR "$base_repo/target/release" "$CARGO_TARGET_DIR/release"
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_RELEASE_SPLIT_DEBUGINFO=unpacked
cargo build --offline --locked --release --no-default-features -p risingwave_cmd_all --bin risingwave -j 4 --message-format=json --config 'profile.release.package.risingwave_license.debug-assertions=true' > "$suite/cargo-messages.jsonl" 2> "$suite/cargo-build.log"
/opt/homebrew/bin/python3 "$suite/stage.py"

"""Read retained pre-matrix samples for the 312.94 MiB versus 79.91 MiB question."""
from pathlib import Path
import gzip,json,sys

suite=Path(__file__).resolve().parent
new_suite=Path((suite/'historical-gap64-suite.txt').read_text().strip())
old_suite=Path((new_suite/'control-gap0-suite.txt').read_text().strip())
sys.path.insert(0,str(new_suite))
from analyze import metrics,parse_lines,delta

result={}
for label,base in [('gap0',old_suite),('gap64k',new_suite)]:
 arm=base/'p1-cold-ranges';r=json.loads((arm/'cold-ranges-analysis.json').read_text())
 before=metrics((arm/'before.prom').read_bytes());end=metrics((arm/'after.prom').read_bytes())
 source=json.loads((arm/'source-checkpoint.json').read_text())
 cut=parse_lines(source['metrics'])
 scopes={}
 for scope,last in [('source_checkpoint',cut),('whole_query',end)]:
  count=lambda metric,**labels:int(delta(before,last,metric,**labels))
  bounded_names={m for m,l in last if m.startswith('object_store_read_request_bytes_')}
  logical_bytes=(count('object_store_read_request_bytes_sum') if bounded_names else None)
  direct=count('state_store_cold_range_prefetch_read_bytes_sum')
  physical=count('object_store_operation_bytes_sum',type='read')
  gap=count('object_store_read_scheduler_overread_bytes')
  scopes[scope]=dict(physical_gets=count('object_store_operation_bytes_count',type='read'),physical_bytes=physical,
   logical_requests=count('object_store_read_requests'),logical_bounded_bytes=logical_bytes,
   requested_bytes_metric_captured=bool(bounded_names),
   request_routes={route:count('object_store_read_requests',route=route) for route in ('scheduled','unbounded','oversized','direct','empty_range')},
   prefetch_direct_segments=count('state_store_cold_range_prefetch_read_bytes_count'),prefetch_direct_bytes=direct,
   singleton_registrations=count('state_store_cold_range_prefetch_single_blocks'),
   scheduler_overread_bytes=gap,
   scheduler_merged_requests=count('object_store_read_scheduler_events',event='merged_requests'),
   scheduler_inflight_reused=count('object_store_read_scheduler_events',event='inflight_reused'),
   scheduler_cancel_events={event:count('object_store_read_scheduler_events',event=event) for event in ('cancelled_before_dispatch','group_cancelled','range_fallback_requests')},
   retries=count('object_store_request_retry_count',type='read'),failures=count('object_store_failure_count',type='read'),
   outcomes={stage:{outcome:count('object_store_read_outcomes',stage=stage,outcome=outcome)
       for outcome in ('ok','error','cancelled')} for stage in ('logical','physical','attempt')},
   residual_physical_minus_prefetch_and_overread=physical-direct-gap,
   residual_physical_minus_bounded_logical_and_overread=(None if logical_bytes is None else physical-logical_bytes-gap))
  assert scopes[scope]['logical_requests']-scopes[scope]['scheduler_merged_requests']-scopes[scope]['scheduler_inflight_reused']==scopes[scope]['physical_gets']
  assert scopes[scope]['retries']==scopes[scope]['failures']==0
 # A full scrape just before first provider establishes the old phase-boundary ambiguity.
 pre=[]
 with gzip.open(arm/'samples.jsonl.gz','rt') as f:
  for t,_,raw in map(json.loads,f):
   if t < r['operator_milestones_s']['first_provider']:pre.append((t,parse_lines(raw)))
 t,last_pre=max(pre,key=lambda pair:pair[0])
 scopes['checkpoint_boundary']=dict(source_checkpoint_s=r['source_checkpoint_s'],source_complete_bracket_s=r['source_complete_bracket_s'],
  first_provider_s=r['operator_milestones_s']['first_provider'],last_pre_provider_full_sample_s=t,
  source_rows_after_last_pre_provider=int(delta(last_pre,cut,'stream_snapshot_backfill_consume_snapshot_row_count',stage='consuming_snapshot')),
  physical_bytes_after_last_pre_provider=int(delta(last_pre,cut,'object_store_operation_bytes_sum',type='read')),
  physical_gets_after_last_pre_provider=int(delta(last_pre,cut,'object_store_operation_bytes_count',type='read')),
  prefetch_direct_bytes_after_last_pre_provider=int(delta(last_pre,cut,'state_store_cold_range_prefetch_read_bytes_sum')))
 result[label]=scopes

a,b=(result[k]['source_checkpoint'] for k in ('gap0','gap64k'))
source_delta={name:b[name]-a[name] for name in ('physical_gets','physical_bytes','logical_requests','prefetch_direct_segments','prefetch_direct_bytes',
 'scheduler_overread_bytes','scheduler_merged_requests','scheduler_inflight_reused','residual_physical_minus_prefetch_and_overread')}
assert source_delta['physical_bytes']==source_delta['prefetch_direct_bytes']+source_delta['scheduler_overread_bytes']+source_delta['residual_physical_minus_prefetch_and_overread']
result['source_delta_accounting']=source_delta
result['coverage_limits']=[
 'The source checkpoint capture did not select object_store_read_request_bytes; source bounded logical bytes are unavailable.',
 'Full before/after scrapes retain whole-query requested bytes, but unbounded logical read sizes are absent by definition.',
 'The residual is computed accounting, combining ordinary/metadata reads, overlap/reuse/cancellation and planning-versus-completion effects.',
 'The gap64 source checkpoint includes some downstream startup; its final 498 GETs include both remaining source and early provider work.',
 'All additional analysis reads existing files; no historical workload rerun was used.',
]
(suite/'historical-byte-ledger.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
rows=['| Counter | Gap 0 | Gap 64 KiB | Difference |','| --- | ---: | ---: | ---: |']
for key,label in [('physical_bytes','Physical read MiB'),('prefetch_direct_bytes','Declared direct-prefetch MiB'),
 ('scheduler_overread_bytes','Explicit scheduler gap MiB'),('residual_physical_minus_prefetch_and_overread','Derived remaining MiB')]:
 x,y=a[key]/2**20,b[key]/2**20;rows.append(f'| {label} | {x:.6f} | {y:.6f} | {y-x:+.6f} |')
for key in ('physical_gets','logical_requests','prefetch_direct_segments','singleton_registrations','scheduler_merged_requests','scheduler_inflight_reused'):
 rows.append(f'| {key} | {a[key]:,} | {b[key]:,} | {b[key]-a[key]:+,} |')
(suite/'historical-byte-ledger.md').write_text('\n'.join(rows)+'\n')
print('\n'.join(rows))

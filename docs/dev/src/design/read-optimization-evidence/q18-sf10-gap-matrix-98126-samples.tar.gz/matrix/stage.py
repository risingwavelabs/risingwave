from pathlib import Path
import hashlib, json, os, subprocess, shutil

s=Path(__file__).resolve().parent
root=Path((s/'source-worktree.txt').read_text().strip()).resolve()
plan=json.loads((s/'build-plan.json').read_text())
def git(*a):
    return subprocess.check_output(['git','-C',root,*a],text=True).strip()
def sha(p):
    with Path(p).open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
assert git('rev-parse','HEAD')==plan['head'] and not git('status','--porcelain=v1')
assert all(sha(root/file)==h for file,h in plan['source_sha256'].items())
entries=[e for l in (s/'cargo-messages.jsonl').open() if (e:=json.loads(l)).get('reason')=='compiler-artifact']
builds=[e for l in (s/'cargo-messages.jsonl').open() if (e:=json.loads(l)).get('reason')=='build-finished']
assert builds==[dict(reason='build-finished',success=True)], builds
binary,=[e for e in entries if e.get('executable') and e['target']['name']=='risingwave']
license,=[e for e in entries if e['target']['name']=='risingwave_license' and e['target']['kind']==['lib']]
assert not binary['fresh'] and binary['features']==[]
for e in (binary,license):
    assert e['profile']['opt_level']=='3' and not e['profile']['test'] and str(root) in e['target']['src_path']
assert not binary['profile']['debug_assertions'] and license['profile']['debug_assertions']
for package in ('risingwave_storage','risingwave_object_store','risingwave_stream'):
    rows=[e for e in entries if e['target']['name']==package]
    assert rows and all(str(root) in e['target']['src_path'] for e in rows)
assert any('foyer@' in e['package_id'] and '02d6b5ebc7516121ab0ad84ad8780623cfa1c8c5' in e['package_id']
           for e in entries), 'Pinned Foyer not present'
dest=s/'risingwave'
subprocess.run(['cp','-c',binary['executable'],dest],check=True)
assert sha(dest)==sha(binary['executable'])
(s/'license-artifact.json').write_text(json.dumps(license,indent=2)+'\n')
(s/'service-artifact.json').write_text(json.dumps(dict(source_head=plan['head'],
    source_diff_sha256=plan['source_diff_sha256'],source=str(root),artifact=binary,
    profile=binary['profile'],sha256=sha(dest),bytes=dest.stat().st_size),indent=2)+'\n')
print('Staged release',sha(dest),flush=True)

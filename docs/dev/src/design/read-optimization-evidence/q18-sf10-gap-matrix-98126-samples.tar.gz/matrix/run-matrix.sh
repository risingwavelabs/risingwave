#!/usr/bin/env bash
set -euo pipefail
suite="$1"
python=/opt/homebrew/bin/python3
"$python" - "$suite" <<'PY'
import json,sys
from pathlib import Path
s=Path(sys.argv[1]); a=json.loads((s/'service-artifact.json').read_text())
assert a['source_head']=='98126f898412f675ebdd406c35cd273f4972dd2b'
assert a['profile']['opt_level']=='3' and not a['profile']['debug_assertions']
PY
for arm in p1-gap0 p1-gap64k p2-gap64k p2-gap0 p3-gap0 p3-gap64k; do
  if [[ -f "$suite/$arm/matrix-analysis.json" ]]; then continue; fi
  "$python" - "$suite" "$arm" <<'PY'
import json,shutil,sys,time
from pathlib import Path
s=Path(sys.argv[1]); arm=sys.argv[2]
assert not (s/arm).exists()
assert shutil.disk_usage(s).free >= 90*2**30
with (s/'matrix-events.jsonl').open('a') as f:
 f.write(json.dumps(dict(event='arm_start',arm=arm,unix=time.time()))+'\n')
PY
  "$python" -u "$suite/run-matrix-arm.py" "$arm" on > "$suite/$arm-driver.log" 2>&1
  "$python" -u "$suite/analyze-matrix-arm.py" "$arm" > "$suite/$arm-analysis.log" 2>&1
  "$python" - "$suite" "$arm" <<'PY'
import json,sys,time
from pathlib import Path
s=Path(sys.argv[1]); arm=sys.argv[2]
d=json.loads((s/arm/'result.json').read_text())
assert (s/arm/'cleanup.txt').is_file()
with (s/'matrix-events.jsonl').open('a') as f:
 f.write(json.dumps(dict(event='arm_done',arm=arm,seconds=d['seconds'],unix=time.time()))+'\n')
print(arm, 'completed', round(d['seconds'],2),flush=True)
PY
done

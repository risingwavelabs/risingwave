"""Summarize same-binary SF10 Q18 MultiGet runs and operator phase counters."""
from collections import defaultdict
from datetime import datetime
import gzip
import json
from pathlib import Path
import re
import sys
from statistics import mean

ROOT = Path(__file__).resolve().parent
from metric_reader import delta, metrics

ARMS = ('p1-off', 'p1-on', 'p2-on', 'p2-off', 'p3-on')
TARGETS = {'31': '53', '20': '27'}
GET_TAGS = {'type': 'read'}
BLOCK_COUNTERS = ('meta_total', 'meta_miss', 'meta_batch_ready', 'meta_batch_retained',
                  'meta_batch_budget_reject', 'meta_batch_oversized', 'data_total', 'data_miss')
AGG_COUNTERS = ('lookup_total_count', 'lookup_miss_count', 'chunk_lookup_total_count',
                'chunk_lookup_miss_count', 'state_cache_lookup_count', 'state_cache_miss_count')


def load(path):
    return json.loads(path.read_text())


def parse_lines(lines):
    return metrics('\n'.join(lines).encode())


def histogram(before, after, name, **labels):
    count = int(delta(before, after, name + '_count', **labels))
    total = delta(before, after, name + '_sum', **labels)
    bins = defaultdict(int)
    for (metric, series), value in after.items():
        if metric == name + '_bucket' and labels.items() <= dict(series).items():
            bins[float(dict(series)['le'])] += int(value - before.get((metric, series), 0))
    ordered = sorted(bins.items())
    def upper(fraction):
        return next((bound for bound, value in ordered if count and value >= fraction * count), None)
    unbucketed = {}
    previous = 0
    for bound, value in ordered:
        if value != previous:
            assert value > previous
            unbucketed[str(bound)] = value - previous
        previous = value
    return dict(count=count, sum=total, mean=total / count if count else None,
                p50_upper=upper(.50), p95_upper=upper(.95), p99_upper=upper(.99),
                populated_buckets=unbucketed)


def section(samples, first, last):
    """Measure deltas using the closest full scrapes to exact phase markers."""
    begin = min(samples, key=lambda sample: abs(sample[0] - first))
    end = min(samples, key=lambda sample: abs(sample[0] - last))
    included = [sample for sample in samples if begin[0] <= sample[0] <= end[0]]
    start_time, _, before = begin
    end_time, _, after = end
    cpu = delta(before, after, 'process_cpu_seconds_total')
    peak_cores = max((delta(l[2], r[2], 'process_cpu_seconds_total') / (r[0] - l[0])
                      for l, r in zip(included, included[1:]) if r[0] - l[0] > 2), default=None)
    read_errors = {layer: int(delta(before, after, 'object_store_read_outcomes', stage=layer, outcome='error'))
                   for layer in ('attempt', 'physical', 'logical')}
    return dict(wall_s=last - first, log_boundaries_s=[first, last],
                scrape_boundaries_s=[start_time, end_time], cpu_s=cpu,
                mean_cores=cpu / (end_time - start_time), peak_sampled_cores=peak_cores,
                gets=int(delta(before, after, 'object_store_operation_bytes_count', **GET_TAGS)),
                bytes=int(delta(before, after, 'object_store_operation_bytes_sum', **GET_TAGS)),
                gets_le_64k=int(delta(before, after, 'object_store_operation_bytes_bucket', le='65536', **GET_TAGS)),
                backend=histogram(before, after, 'object_store_operation_latency', **GET_TAGS),
                admission=histogram(before, after, 'object_store_read_scheduler_admission_duration_seconds'),
                dispatch=histogram(before, after, 'object_store_read_scheduler_queue_duration_seconds'),
                peak_rss_mib=max(sample[1] for sample in included),
                backend_failures=int(delta(before, after, 'object_store_failure_count', **GET_TAGS)),
                backend_retries=int(delta(before, after, 'object_store_request_retry_count', **GET_TAGS)),
                read_errors=read_errors)


def time_from_line(line):
    return datetime.fromisoformat(line.split()[0])


def boundaries(arm, wall):
    query_log = (arm / 'logs/query.log').read_text().splitlines()
    start_line, end_line = [line for line in query_log
                            if re.search(r'session_id=\d+ sql=CREATE MATERIALIZED VIEW tpch_q18 ', line)]
    start, finish = time_from_line(start_line), time_from_line(end_line)
    log_wall = (finish - start).total_seconds()
    # Phase marks in log time are converted to the sampler timeline, which starts
    # just before psql launch and includes its final exit.
    offset = (wall - log_wall) / 2
    assert abs(offset) < 1.0, (arm, wall, log_wall)

    def relative(line):
        return (time_from_line(line) - start).total_seconds() + offset

    providers = defaultdict(list)
    provider_actors = defaultdict(set)
    start_pattern = re.compile(r'actor_id=(\d+).*Start backfill of locality provider with fragment id: (\d+)')
    for line in (arm / 'logs/compute-node-5688.log').open():
        if match := start_pattern.search(line):
            actor, fragment = match.groups()
            providers[fragment].append(relative(line))
            provider_actors[fragment].add(actor)
    expected = {'20', '22', '24', '27', '29', '31'}
    assert set(providers) == expected, providers
    assert all(len(ids) == 4 for ids in provider_actors.values()), provider_actors

    graph_merge = [relative(line) for line in (arm / 'logs/meta-node-5690.log').open()
                   if 'start merging into database graph' in line and 'job_id=24 ' in line]
    assert len(graph_merge) == 1, graph_merge
    marks = {f'start_{fragment}': min(times) for fragment, times in providers.items()}
    marks.update(first_provider=min(map(min, providers.values())), graph_merge=graph_merge[0], ddl_end=wall)
    assert 0 < marks['first_provider'] <= marks['start_31'] < marks['start_24'] \
        < marks['start_22'] < marks['start_20'] < marks['graph_merge'] <= wall, marks
    return marks, provider_actors


def highwater(samples, metric, **labels):
    peaks = defaultdict(float)
    for _, _, snapshot in samples:
        for (name, series), value in snapshot.items():
            if name == metric and labels.items() <= dict(series).items():
                peaks[series] = max(value, peaks[series])
    return sum(peaks.values())


def actor_metrics(samples, actor, fragment, table):
    labels = dict(actor_id=actor, fragment_id=fragment)
    values = {counter: int(highwater(samples, f'stream_agg_{counter}', **labels, table_id=table))
              for counter in AGG_COUNTERS}
    values['poll_s'] = highwater(samples, 'stream_actor_poll_duration', **labels) / 1e9
    values['runnable_wait_s'] = highwater(samples, 'stream_actor_scheduled_duration', **labels) / 1e9
    return values


def local_table(before, after, table):
    fields = dict(table_id=table)
    result = {name: int(delta(before, after, 'state_store_sst_store_block_request_counts', **fields, type=name))
              for name in BLOCK_COUNTERS}
    result['meta_candidates'] = result['meta_total'] + result['meta_batch_ready']
    result['get_key_count'] = int(delta(before, after, 'state_store_get_key_size_count', **fields))
    result['bloom_checks'] = int(delta(before, after, 'state_store_bloom_filter_check_counts', **fields, type='get'))
    result['bloom_negative'] = int(delta(before, after, 'state_store_bloom_filter_true_negative_counts', **fields, type='get'))
    result['scalar_gets'] = histogram(before, after, 'state_store_get_duration', **fields)
    result['batch_duration'] = histogram(before, after, 'state_store_get_batch_duration', **fields)
    result['batch_keys'] = histogram(before, after, 'state_store_get_batch_keys', **fields)
    result['batch_concurrency'] = histogram(before, after, 'state_store_get_batch_concurrency', **fields)
    result['batch_outcomes'] = {outcome: int(delta(before, after, 'state_store_get_batch_outcomes', **fields, outcome=outcome))
                                for outcome in ('ok', 'error', 'cancelled')}
    n = result['batch_keys']['count']
    assert result['batch_duration']['count'] == n == result['batch_concurrency']['count'] == sum(result['batch_outcomes'].values())
    assert result['batch_outcomes']['error'] == result['batch_outcomes']['cancelled'] == 0, result
    return result


def phase_distribution(samples, before, table, completed):
    """First, 1%, median, 99%, and last observed state lookups by scheduled scrape."""
    bounds = {}
    for time, _, current in samples:
        rows = delta(before, current, 'state_store_get_key_size_count', table_id=table)
        for fraction in (0, .01, .5, .99, 1):
            if rows > 0 and rows >= completed * fraction:
                bounds.setdefault(str(fraction), time)
    return bounds


def collect(arm):
    result = load(arm / 'result.json')
    controls = load(arm / 'run-controls.json')
    assert (result['source_rows'], result['oracle_rows'], result['q18_actors'], result['q18_fragments']) == (136_472_104, 100, 53, 14)
    assert result['oracle_matches'] and controls['advertised_slots'] == 12 and controls['locality_providers'] == 6
    assert result['fragment_actors'] == {str(i): 1 if i == 19 else 4 for i in range(19, 33)}
    scheduler = controls['config']['storage']['object_store']['read_scheduler']
    assert scheduler['dedicated_io_runtime_workers'] == 6
    assert all(controls['actual_cn_threads'][key] == val for key, val in (
        ('rw-streaming', 8), ('rw-read-io', scheduler['dedicated_io_runtime_workers'])))
    assert controls['plan_matches_candidate'] and not controls['targeted_trace'] and not controls['fastrace']
    assert 'pk_conflict: NoCheck' in (arm / 'plan-actual.txt').read_text()
    live_placement = defaultdict(set)
    for line in (arm / 'placement-during.tsv').read_text().splitlines():
        fragment, actor, _, parallelism, *_ = line.split('|')
        if fragment in TARGETS or fragment == '23':
            assert parallelism == '4', line
            live_placement[fragment].add(actor)
    assert set(live_placement) == set(TARGETS) | {'23'} and all(len(actors) == 4 for actors in live_placement.values())
    assert 'listeners and containers absent' in (arm / 'cleanup.txt').read_text()
    wall = result['seconds']
    before, after = [metrics((arm / file).read_bytes()) for file in ('before.prom', 'after.prom')]
    rss = lambda m: m[('process_resident_memory_bytes', ())] / 2**20
    samples = [(0.0, rss(before), before)]
    with gzip.open(arm / 'samples.jsonl.gz', 'rt') as stream:
        for row in stream:
            when, rss_kib, lines = json.loads(row)
            samples.append((when, rss_kib / 1024, parse_lines(lines)))
    if (arm / 'source-samples.jsonl.gz').is_file():
        with gzip.open(arm / 'source-samples.jsonl.gz', 'rt') as source_stream:
            for when, rss_kib, lines in map(json.loads, source_stream):
                samples.append((when, rss_kib / 1024, parse_lines(lines)))
        samples.sort(key=lambda sample: sample[0])
    samples.append((wall, rss(after), after))
    cutoff = load(arm / 'source-checkpoint.json')
    assert cutoff['per_table'] == {'6': 1_500_000, '11': 15_000_000, '16': 119_972_104}
    if not any(abs(t - cutoff['elapsed_s']) < .00001 for t, _, _ in samples):
        assert 0 < cutoff['elapsed_s'] < wall
        samples.append((cutoff['elapsed_s'], cutoff['rss_kib'] / 1024, parse_lines(cutoff['metrics'])))
        samples.sort(key=lambda sample: sample[0])
    source_end = cutoff['elapsed_s']
    source_counts = []
    for row in (arm / 'congestion.jsonl').read_text().splitlines():
        start, end, raw = json.loads(row)
        if not isinstance(raw, list):
            continue
        parsed = parse_lines(raw)
        n = sum(delta(before, parsed, 'stream_snapshot_backfill_consume_snapshot_row_count',
                      stage='consuming_snapshot', table_id=table) for table in cutoff['per_table'])
        source_counts.append((start, end, n))
    end_i = next(i for i, (_, _, count) in enumerate(source_counts) if count == 136_472_104)
    source_bracket = [source_counts[end_i - 1][0], source_counts[end_i][1]]
    marks, actor_ids = boundaries(arm, wall)
    phase_bounds = {'whole': (0, wall), 'through_source': (0, source_end), 'after_source': (source_end, wall),
                    'first_to_24': (marks['first_provider'], marks['start_24']),
                    '24_to_22': (marks['start_24'], marks['start_22']),
                    '22_to_20': (marks['start_22'], marks['start_20']),
                    'agg31_to_24': (marks['start_31'], marks['start_24']),
                    'agg20_to_merge': (marks['start_20'], marks['graph_merge'])}
    phases = {phase: section(samples, start, end) for phase, (start, end) in phase_bounds.items()}
    phases['whole']['peak_rss_mib'] = max(phases['whole']['peak_rss_mib'], *[
        line[3] / 1024 for line in map(json.loads, (arm / 'startup-samples.jsonl').open()) if len(line) == 4
    ])
    assert phases['whole']['gets'] == phases['whole']['backend']['count']
    assert phases['whole']['backend_failures'] == phases['whole']['backend_retries'] == 0
    assert not any(phases['whole']['read_errors'].values()), phases['whole']['read_errors']
    assert phases['whole']['gets'] == phases['through_source']['gets'] + phases['after_source']['gets']

    tables = {}
    for fragment, table in TARGETS.items():
        stats = local_table(before, after, table)
        actors = {actor: actor_metrics(samples, actor, fragment, table) for actor in sorted(actor_ids[fragment], key=int)}
        actor_totals = {key: sum(actor[key] for actor in actors.values()) for key in next(iter(actors.values()))}
        observed = phase_distribution(samples, before, table, stats['get_key_count'])
        stats['actor_peak_counters'] = actors
        stats['actor_total'] = actor_totals
        stats['get_key_count_progress_scrapes'] = observed
        stats['batch_keys_fraction'] = stats['batch_keys']['sum'] / stats['get_key_count']
        stats['storage_activity'] = {}
        active_bounds = (observed['0.01'], observed['0.99'])
        stats['observed_1_to_99pct'] = section(samples, *active_bounds)
        for phase, (start, end) in {**phase_bounds, 'observed_1_to_99pct': active_bounds}.items():
            left = min(samples, key=lambda sample: abs(sample[0] - start))
            right = min(samples, key=lambda sample: abs(sample[0] - end))
            retained = local_table_phase(left[2], right[2], table)
            interval = [sample for sample in samples if left[0] <= sample[0] <= right[0]]
            for k, name in (('poll_s', 'stream_actor_poll_duration'),
                            ('runnable_wait_s', 'stream_actor_scheduled_duration')):
                retained[k] = sum(highwater(interval, name, fragment_id=fragment, actor_id=actor)
                                  - highwater([left], name, fragment_id=fragment, actor_id=actor)
                                  for actor in actors) / 1e9
            stats['storage_activity'][phase] = retained
        if result['multiget']:
            assert stats['batch_keys']['count'] > 0 and stats['batch_keys']['count'] == stats['batch_outcomes']['ok']
        else:
            assert not stats['batch_keys']['count'] and stats['meta_batch_ready'] == stats['meta_batch_budget_reject'] == 0
        tables[table] = stats
    total_batches = delta(before, after, 'state_store_get_batch_keys_count')
    assert total_batches == sum(t['batch_keys']['count'] for t in tables.values())
    assert all(actor_ids[fragment] == live_placement[fragment] for fragment in TARGETS)
    phase_start = min(samples, key=lambda sample: abs(sample[0] - marks['start_24']))
    phase_end = min(samples, key=lambda sample: abs(sample[0] - marks['start_22']))
    join_probe = local_table_phase(phase_start[2], phase_end[2], '38')
    join_probe['meta_candidates'] = join_probe['meta_total'] + join_probe['meta_batch_ready']
    join_probe['bloom_negative'] = int(delta(phase_start[2], phase_end[2], 'state_store_bloom_filter_true_negative_counts',
                                           table_id='38', type='iter'))
    return dict(controls=controls, result=result, phases=phases, source_bracket_s=source_bracket, logs=dict(milestones_s=marks),
                tables=tables, table38_24_to_22=join_probe, min_free_gib=min(load_line[1] / 2**30 for load_line in
                    map(json.loads, (arm / 'disk-free.jsonl').open())))


def local_table_phase(before, after, table):
    fields = dict(table_id=table)
    result = {name: int(delta(before, after, 'state_store_sst_store_block_request_counts', **fields, type=name))
              for name in BLOCK_COUNTERS}
    result['get_key_count'] = int(delta(before, after, 'state_store_get_key_size_count', **fields))
    result['batch_count'] = int(delta(before, after, 'state_store_get_batch_keys_count', **fields))
    result['batch_keys'] = int(delta(before, after, 'state_store_get_batch_keys_sum', **fields))
    return result


def pair_table(arms, path):
    def value(arm, key):
        if key == 'source_bracket_s':
            return mean(arm[key])
        phase, metric = key.split('.', 1)
        if metric == 'mean_backend_ms':
            return arm['phases'][phase]['backend']['mean'] * 1000
        if metric == 'p99_backend_ms':
            return arm['phases'][phase]['backend']['p99_upper'] * 1000
        return arm['phases'][phase][metric]

    pairs = [(arms[f'p{i}-off'], arms[f'p{i}-on']) for i in (1, 2) if all(f'p{i}-{mode}' in arms for mode in ('off', 'on'))]
    print_parts = ['| Metric, OFF → ON |' + ''.join(f' Pair {j} |' for j in range(1, len(pairs) + 1)),
                   '| --- |' + ' ---: |' * len(pairs)]
    for label, key, divisor, fmt in (
        ('CREATE MV wall, s', 'whole.wall_s', 1, '.2f'),
        ('Source complete midpoint, s', 'source_bracket_s', 1, '.2f'),
        ('Agg31 provider start → provider 24, s', 'agg31_to_24.wall_s', 1, '.2f'),
        ('Provider 24 → 22, s', '24_to_22.wall_s', 1, '.2f'),
        ('Provider 22 → 20, s', '22_to_20.wall_s', 1, '.2f'),
        ('Agg20 provider start → graph merge, s', 'agg20_to_merge.wall_s', 1, '.2f'),
        ('CN CPU, s', 'whole.cpu_s', 1, ',.0f'),
        ('CN mean cores', 'whole.mean_cores', 1, '.2f'),
        ('CN sampled peak cores', 'whole.peak_sampled_cores', 1, '.2f'),
        ('CN GETs', 'whole.gets', 1, ',.0f'),
        ('GETs through source', 'through_source.gets', 1, ',.0f'),
        ('GETs after source', 'after_source.gets', 1, ',.0f'),
        ('CN read GiB', 'whole.bytes', 2**30, '.2f'),
        ('CN GET mean, ms', 'whole.mean_backend_ms', 1, '.2f'),
        ('CN GET p99 bucket, ms', 'whole.p99_backend_ms', 1, '.0f'),
        ('CN peak RSS, MiB', 'whole.peak_rss_mib', 1, ',.0f'),
    ):
        print_parts.append(f'| {label} |' + ''.join(' ' + ' → '.join(
            format(value(a, key) / divisor, fmt) for a in pair) + ' |' for pair in pairs))
    path.write_text('\n'.join(print_parts) + '\n')
    print(*print_parts, sep='\n')


if __name__ == '__main__':
    arms = {}
    for name in ARMS:
        candidates = sorted([ROOT / name, *ROOT.glob(f'{name}-retry*')])
        completed = [x for x in candidates if (x / 'result.json').is_file() and (x / 'cleanup.txt').is_file()]
        if not completed:
            continue
        assert len(completed) == 1, name
        arm = completed[0]
        analysis = collect(arm)
        (arm / 'analysis.json').write_text(json.dumps(analysis, indent=2) + '\n')
        arms[name] = analysis
    for i in (1, 2):
        off, on = [arms.get(f'p{i}-{mode}') for mode in ('off', 'on')]
        if off and on:
            expected = json.loads(json.dumps(off['controls']['config']))
            expected['storage']['read_batch']['enabled'] = True
            assert expected == on['controls']['config']
            assert off['controls']['seed_manifest'] == on['controls']['seed_manifest']
            assert off['controls']['binary_sha256'] == on['controls']['binary_sha256']
            a, b = (ROOT / x['result']['arm'] for x in (off, on))
            for name in ('query.sql', 'plan-actual.txt', 'source-sst-fingerprint.txt'):
                assert (a / name).read_bytes() == (b / name).read_bytes(), name
            assert sorted((a / 'oracle.txt').read_text().splitlines()) == sorted((b / 'oracle.txt').read_text().splitlines())
    (ROOT / 'paired-analysis.json').write_text(json.dumps(arms, indent=2) + '\n')
    if any(f'p{i}-off' in arms and f'p{i}-on' in arms for i in (1, 2)):
        pair_table(arms, ROOT / 'paired-runtime.md')

"""Measure Q18 MultiGet on a disposable SF10 cold clone."""
from collections import Counter
from contextlib import contextmanager
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
import tomllib

suite = Path(__file__).resolve().parent
main = suite.parents[2]
a_archive = suite.parent / "sf3-q18-pristine-main-4g"
b_archive = suite.parent / "sf3-q18-dev-test-release"
arm, toggle = sys.argv[1:]
assert re.fullmatch(r"p[123]-gap(?:0|64k)(?:-retry\d+)?", arm) and toggle == "on"
gap_bytes = 65536 if "-gap64k" in arm else 0
multiget = toggle == "on"
slot_count = 12
parallelism = "fixed4"
mode = "cold_ranges"
scheduler = True
reuse = True
archive = suite
base = "98126f898412f675ebdd406c35cd273f4972dd2b"
patch_sha = hashlib.sha256(b"").hexdigest()
repo = source_repo = Path((suite / "source-worktree.txt").read_text().strip()).resolve()
def verify():
    assert command_output("git", "-C", str(source_repo), "rev-parse", "HEAD") == base
    diff = subprocess.check_output(["git", "diff", "--binary", "HEAD"], cwd=source_repo)
    assert hashlib.sha256(diff).hexdigest() == patch_sha
    assert not command_output("git", "-C", str(source_repo), "ls-files", "--others", "--exclude-standard")


out = suite
thread_info = suite.parent / "dedicated-io-q18-locality-on/thread-info"
root = out.parent
sys.path.insert(0, str(root))
import run_q18_group_q_sampler as r

reference = root / "sf3-q18-dev-test-release/b-2w-p32"
historical = root / "runtime-q64-prep-trim-src"
run = suite / arm
runtime = repo / ".risingwave"
binary = archive / "risingwave"

PREFETCH_GAUGE = "state_store_prefetch_memory_size"
SOURCE_COUNTER = "stream_snapshot_backfill_consume_snapshot_row_count"
SOURCE_ROWS = {"6": 1_500_000, "11": 15_000_000, "16": 119_972_104}
LICENSE_EXPECTED = dict(effective=True, tier="all", rwu_limit="unlimited", test_feature=True, runtime_default=True)
source_checkpoint_lock = threading.Lock()

def record(name, data):
    (run / (name + ".json")).write_text(json.dumps(data, indent=2) + "\n")

def digest(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()

def command_output(*args):
    return subprocess.check_output(args, text=True).strip()

@contextmanager
def launch_files():
    # Keep all mutable RiseDev files in the isolated checkout.
    for path in (".risingwave", "risedev-components.user.env", "risedev-profiles.user.yml"):
        assert not (repo/path).exists(), path
    profile = repo/"risedev.yml"
    original = profile.read_bytes()
    assert original == (historical/"risedev.yml").read_bytes()
    try:
        assert not (repo/"target/debug/risedev-dev").exists()
        (repo/"target/debug").mkdir(parents=True,exist_ok=True)
        (repo/"target/debug/risedev-dev").symlink_to(main/"target/debug/risedev-dev")
        for filename in ("risedev-components.user.env","risedev-profiles.user.yml"):
            shutil.copyfile(historical/filename,repo/filename)
        (runtime/"bin").mkdir(parents=True)
        for filename in ("minio", "mcli", "prometheus", "lakekeeper"):
            executable=(historical/".risingwave/bin"/filename).resolve(strict=True)
            (runtime/"bin"/filename).symlink_to(executable)
        shutil.copytree(historical/".risingwave/bin/grafana", runtime/"bin/grafana", symlinks=True)
        dashboard = historical/".risingwave/config"
        (runtime/"config").mkdir()
        for path in dashboard.glob("*.json"):
            shutil.copyfile(path, runtime/"config"/path.name)
        profile_text = original.decode()
        if slot_count != 4:
            begin, full = profile_text.split("  full:\n    steps:\n", 1)
            head, tail = full.split("  standalone-full-peripherals:", 1)
            assert head.count("      - use: compute-node\n") == 1
            # The template is read by the full compute service. Only this isolated profile is used.
            compute, tail = tail.split("  compute-node:\n", 1)
            assert tail.count("    parallelism: 4\n") == 1
            tail = tail.replace("    parallelism: 4\n", f"    parallelism: {slot_count}\n", 1)
            profile_text = begin + "  full:\n    steps:\n" + head + "  standalone-full-peripherals:" + compute + "  compute-node:\n" + tail
        r.SRC, r.RUNTIME, r.PROFILE = repo, runtime, profile_text
        r.BINARY = binary
        r.ROOT = suite
        r.SEED = root/"sf10-seed"/"seed-image"
        r.ENV.update(PATH=str(archive)+os.pathsep+os.environ["PATH"],RUST_LOG="info,risingwave_meta::controller::system_param=error",
                     USE_SYSTEM_RISINGWAVE="true")
        for key in ("RW_Q18_SOURCE_BLOCKWISE", "RW_HUMMOCK_ITER_PROFILE", "RW_Q18_PERMIT_HANDOFF",
                    "TOKIO_WORKER_THREADS", "RUST_LOG_SPAN_EVENTS"):
            r.ENV.pop(key, None)
        r.ENV.update(dict(line.split("=", 1) for line in (suite / "profile.env").read_text().splitlines()))
        r.ENV.pop("RW_Q18_IO_DIAGNOSTIC", None)
        assert not any(r.ENV.get(key) for key in ("RW_LICENSE_KEY", "RW_LICENSE_KEY_PATH"))
        yield
    finally:
        profile.write_bytes(original)
        if run.exists() and (runtime/"log").exists() and not (run/"logs").exists():
            archive_logs(runtime / "log", run / "logs")
        if not r.active:
            (repo/"target/debug/risedev-dev").unlink(missing_ok=True)
            if runtime.exists():
                shutil.rmtree(runtime)
            for name in ("risedev-components.user.env","risedev-profiles.user.yml"):
                (repo/name).unlink(missing_ok=True)

def archive_logs(source, destination):
    # The clone may carry a system parameter from the seed. Keep credential-shaped
    # tokens out of the copied log without recording their contents.
    jwt = re.compile(r"eyJ[A-Za-z0-9_-]{6,}\.[A-Za-z0-9_-]{6,}\.[A-Za-z0-9_-]{6,}")
    destination.mkdir()
    for path in source.iterdir():
        if path.is_file():
            with path.open(errors="replace") as reader, (destination / path.name).open("w") as writer:
                for line in reader:
                    writer.write(jwt.sub("<redacted JWT>", line))

def threads(pid, label):
    snapshot = subprocess.check_output([str(thread_info), pid], text=True)
    (run / f"threads-{label}.tsv").write_text(snapshot)
    rows = [line.split("\t") for line in snapshot.splitlines()]
    totals = Counter(name for _, name, _, _ in rows)
    assert totals["rw-read-io"] == (6 if scheduler else 0), totals
    if label == "before":
        assert totals["rw-streaming"] == 8 and totals["rw-batch"] == 12 and totals["rw-compaction"] == 4, totals
    return totals

reference_config = tomllib.loads((reference / "risingwave.toml").read_text())
config = """[server]
metrics_level = "Debug"

[frontend]
unsafe_enable_local_fs_connector = true

[streaming]
actor_runtime_worker_threads_num = 8
unsafe_disable_strict_consistency = true

[storage]
prefetch_buffer_capacity_mb = 4096
"""
config = (suite / ("gap64k.toml" if gap_bytes else "gap0.toml")).read_text()
assert multiget
parsed = tomllib.loads(config)
assert all(parsed[key] == reference_config[key] for key in ("server", "frontend", "streaming"))
assert parsed["storage"]["read_batch"] == dict(enabled=True, meta_reuse=True)
reference_object_store = reference_config["storage"]["object_store"]
assert parsed["storage"]["object_store"] == dict(
    reference_object_store,
    read_scheduler=dict({k:v for k,v in reference_object_store["read_scheduler"].items() if k!="prefetch_batch_wait_us"}, dedicated_io_runtime_workers=6, max_gap_bytes=gap_bytes),
)
assert parsed["storage"]["blockwise_prefetch"] == dict(mode="cold_ranges", max_blocks=16, max_bytes=1048576)
assert parsed["storage"]["prefetch_buffer_capacity_mb"] == 4096
assert parsed["storage"]["max_prefetch_block_number"] == 16

def host(pid, label):
    now = subprocess.check_output(["uptime"],text=True)
    proc = subprocess.check_output(["ps","-p",pid,"-o","%cpu=,rss=,time="],text=True)
    with (run/"host-load.jsonl").open("a") as f:
        print(json.dumps({"label":label,"load":now.strip(),"cn_process":proc.strip()}), file=f)

def source_rows(series):
    return {table: int(sum(value for (name, labels), value in series.items()
                           if name == SOURCE_COUNTER and ("stage", "consuming_snapshot") in labels
                           and ("table_id", table) in labels))
            for table in SOURCE_ROWS}

def depth_snapshot(elapsed, rss, data):
    rows = source_rows(r.metrics("\n".join(data).encode()))
    with source_checkpoint_lock:
        if sum(rows.values()) >= sum(SOURCE_ROWS.values()) and not (run / "source-checkpoint.json").exists():
            assert rows == SOURCE_ROWS, rows
            record("source-checkpoint", dict(elapsed_s=elapsed, source_rows=sum(rows.values()), per_table=rows,
                                             rss_kib=rss, metrics=data))

def capture(raw):
    prefixes = r.PREFIXES + ("object_store_failure_count", "object_store_request_retry_count",
        PREFETCH_GAUGE, "state_store_cold_range_prefetch_", "object_store_read_request_", "state_store_block_cache_read_events", "state_store_cold_range_buffered_overlap_", "object_store_read_scheduler_partial_overlap_bytes", "object_store_read_request_duration_seconds",
        "stream_join_match_duration_ns", "stream_actor_poll_duration", "state_store_iter_init_duration",
        "state_store_iter_merge_sstable_counts", "state_store_bloom_filter_", "object_store_read_outcomes", "object_store_read_in_flight",
        "state_store_get_batch", "state_store_get_duration", "state_store_get_key_size",
        "stream_agg_", "stream_actor_scheduled_", "stream_executor_", "stream_barrier_", "stream_backfill_")
    return [line for line in raw.decode().splitlines() if line.startswith(prefixes)]

def first_window(origin, pid):
    with (run/"startup-samples.jsonl").open("w",buffering=1) as log:
        for n in range(51):
            due = origin+n*.1
            time.sleep(max(0,due-time.monotonic()))
            start=time.monotonic()
            if start>due+.1:
                continue
            try:
                data = capture(r.scrape())
                rss=int(command_output("ps","-p",pid,"-o","rss="))
                print(json.dumps([start-origin,time.monotonic()-origin,data,rss]),file=log)
                depth_snapshot(start-origin,rss,data)
            except OSError as exc:
                print(json.dumps([start-origin,time.monotonic()-origin,type(exc).__name__]),file=log)

def sample_gauges(origin, stop):
    gauge_prefixes = (SOURCE_COUNTER + "{", PREFETCH_GAUGE + " ", "process_resident_memory_bytes ",
                     "object_store_read_scheduler_groups{", "object_store_read_scheduler_waiting{",
                     "object_store_read_scheduler_in_flight{", "object_store_read_scheduler_reserved{",
                     "object_store_read_in_flight{", "state_store_cold_range_prefetch_budget_")
    source_complete = False
    with (run / "congestion.jsonl").open("w", buffering=1) as gauges, \
            gzip.open(run / "source-samples.jsonl.gz", "wt") as source_samples:
        n = 6
        while not stop.wait(max(0, origin + n - time.monotonic())):
            at = time.monotonic() - origin
            try:
                raw = r.scrape()
                text = raw.decode().splitlines()
                selected = [line for line in text if line.startswith(gauge_prefixes)]
                print(json.dumps([at, time.monotonic() - origin, selected]), file=gauges)
                if not source_complete:
                    data = capture(raw)
                    series = r.metrics(raw)
                    rss = int(sum(value for (name, _), value in series.items()
                                  if name == "process_resident_memory_bytes") / 1024)
                    print(json.dumps([at, rss, data]), file=source_samples)
                    source_samples.flush()
                    depth_snapshot(at, rss, data)
                    source_complete = sum(source_rows(series).values()) >= sum(SOURCE_ROWS.values())
            except OSError as exc:
                print(json.dumps([at, time.monotonic() - origin, type(exc).__name__]), file=gauges)
            n = max(n + 1, int(time.monotonic() - origin) + 1)

def read_license_status():
    query = """
WITH lic AS (SELECT rw_license() AS details)
SELECT details->>'tier', coalesce(details->>'rwu_limit','unlimited') FROM lic;
"""
    checked = subprocess.run(r.SQL, input=query, text=True, capture_output=True, env=r.ENV, cwd=repo)
    if checked.returncode:
        match = re.search(r"CPU core in the cluster \((\d+)\) exceeds the maximum allowed by the license key \((\d+)\)", checked.stderr)
        if match:
            return dict(effective=False, reason="cpu_limit_exceeded", actual=int(match[1]), limit=int(match[2]))
        return dict(effective=False, reason="license_status_query_failed")
    fields = checked.stdout.strip().split("|")
    if len(fields) != 2:
        return dict(effective=False, reason="license_status_unexpected_shape")
    feature = subprocess.run(r.SQL, input="SELECT rw_test_feature('LocalityBackfill');",
                             text=True, capture_output=True, env=r.ENV, cwd=repo)
    default = subprocess.run(r.SQL, input="SELECT setting = '<default>' FROM pg_settings WHERE name = 'license_key';",
                             text=True, capture_output=True, env=r.ENV, cwd=repo)
    return dict(effective=True, tier=fields[0], rwu_limit=fields[1],
                test_feature=feature.returncode == 0 and feature.stdout.strip() == "t",
                runtime_default=default.returncode == 0 and default.stdout.strip() == "t")

def instrument_catalog(suffix, *, require_vnodes):
    fragment_sql = """
SELECT a.fragment_id,a.actor_id,a.worker_id,f.parallelism,f.max_parallelism,f.parallelism_policy
FROM rw_catalog.rw_actors a
JOIN rw_catalog.rw_fragments f USING (fragment_id)
WHERE f.fragment_id BETWEEN 19 AND 32 ORDER BY 1,2;
"""
    r.sql(fragment_sql, run / f"placement-{suffix}.tsv", 10)
    query = """
SELECT f.fragment_id, rw_fragment_vnodes(f.fragment_id)
FROM rw_catalog.rw_fragments f
WHERE f.fragment_id BETWEEN 19 AND 32 ORDER BY 1;
"""
    result = r.sql(query, run / f"vnode-assignments-{suffix}.tsv", 10)
    fragments = {fragment: json.loads(assigned)
                 for line in result.splitlines() for fragment, assigned in [line.split("|", 1)]}
    record(f"vnodes-{suffix}", fragments)
    if require_vnodes:
        assert set(fragments) == {str(n) for n in range(19, 33)}, fragments.keys()
    for actors in fragments.values():
        assigned = [v for vnodes in actors.values() for v in vnodes]
        if assigned:
            assert sorted(assigned) == list(range(len(assigned))), len(assigned)


def main_run():
    artifact = json.loads((archive/"service-artifact.json").read_text())
    assert artifact["profile"]["opt_level"]=="3" and not artifact["profile"]["debug_assertions"]
    assert json.loads((archive/"license-artifact.json").read_text())["profile"]["debug_assertions"]
    verify()
    seed_manifest=json.loads((root/"sf10-seed"/"seed-manifest.json").read_text())
    assert seed_manifest["pg_clean_shutdown"] and seed_manifest["expected_snapshot_rows"]==136_472_104
    assert seed_manifest["last_live_version"]==1346
    assert all((root/"sf10-seed"/"seed-image"/directory).is_dir() for directory in r.STORED_DIRS)
    def startup_command(args, log, timeout=None):
        with log.open("w") as stream:
            subprocess.run(args,cwd=r.SRC,env=r.ENV,stdout=stream,stderr=subprocess.STDOUT,
                           check=True,timeout=None if args==["./risedev","d","full"] else timeout)
    r.command = startup_command
    assert artifact["source_head"] == base and artifact["source_diff_sha256"] == patch_sha
    assert digest(binary) == artifact["sha256"]
    fixed_query = (reference / "query.sql").read_text()
    assert fixed_query == "SET enable_locality_backfill = true;\n" + r.SETUP + r.DDL
    fixed_statement = "SET streaming_parallelism = 4;"
    adaptive_statement = "SET streaming_parallelism = 'adaptive';"
    assert fixed_query.count(fixed_statement) == 1
    query = fixed_query.replace(fixed_statement, adaptive_statement, 1) if parallelism == "adaptive" else fixed_query
    assert (root / "sf10-seed" / "expected.json").read_bytes() == (suite / "expected.json").read_bytes()
    assert not run.exists()
    assert not r.guard.preflight_blockers(), r.guard.preflight_blockers()
    with launch_files():
        r.arm_config = lambda _:config
        try:
            (runtime/"data").mkdir()
            for directory in r.STORED_DIRS:
                subprocess.run(["cp","-cR",str(r.SEED/directory),str(runtime/"data"/directory)],check=True)
            pid = r.start(arm)
            startlog = (runtime/"log/compute-node-5688.log").read_text()
            for expected in (
                "handle clear event current_version_id=1346 table_ids=None",
                "actor_runtime_worker_threads_num: Some(8)",
                "Using OpenDAL to access minio",
                "prefetch_buffer_capacity_mb: Some(4096)",
                "max_prefetch_block_number: 16",
                "disk cache in mock mode",
                "data_file_cache_dir: None",
                "meta_file_cache_dir: None",
            ):
                if expected not in startlog:
                    record("preflight-blocked", dict(reason="missing expected CN startup evidence",
                                                     expected=expected, create_mv_executed=False))
                    raise RuntimeError(f"CN preflight missing: {expected}")
            controls_line, = [line for line in startlog.splitlines() if "storage read controls" in line]
            expected = f"ReadBatchConfig {{ enabled: {str(multiget).lower()}, concurrency: 10, meta_reuse: {str(reuse).lower()}, meta_max_entries: 16, meta_max_bytes: 1048576 }}"
            assert expected in controls_line, controls_line
            fields_text = controls_line.split("BlockwisePrefetchConfig {", 1)[1].split("}", 1)[0]
            fields = {key: value.strip() for key, value in re.findall(r"(\w+): ([^,}]+)", fields_text)}
            for key, val in parsed["storage"]["blockwise_prefetch"].items():
                want = "Some(ColdRanges)" if key == "mode" else str(val)
                assert fields.get(key) == want, (key, want, fields)
            for override in ("prefix_mode", "changelog_mode", "range_scan_mode", "snapshot_backfill_mode", "locality_backfill_mode"):
                assert fields.get(override) == "None", fields
            (run / "runtime-meta-config.txt").write_text(controls_line + "\n")
            assert f"parallelism: {slot_count}" in (run / "expanded.yml").read_text()
            if scheduler:
                found, = [line for line in startlog.splitlines() if "Hummock read scheduler enabled" in line]
                fields = dict(re.findall(r"(\w+): ([^,}]+)",found.split("ReadSchedulerConfig {",1)[1].split("}")[0]))
                for key, val in parsed["storage"]["object_store"]["read_scheduler"].items():
                    expect = str(val).lower() if isinstance(val,bool) else str(val)
                    assert fields.get(key, "").strip() == expect, (key, expect)
            else:
                assert "Hummock read scheduler enabled" not in startlog
            assert tomllib.loads((runtime / "config/risingwave.toml").read_text()) == parsed
            before_threads = threads(pid, "before")
            host(pid, "before")
            record("disk-pre-query", {"free":shutil.disk_usage(repo).free})
            workers = "SELECT id, host, port, state, parallelism, is_streaming, is_serving, resource_group, system_total_cpu_cores " \
                      "FROM rw_catalog.rw_worker_nodes WHERE type='WORKER_TYPE_COMPUTE_NODE' ORDER BY id;"
            placement = r.sql(workers,run/"compute-before.txt")
            parts = placement.split("|")
            assert len(parts)==9 and parts[3:8]==["RUNNING",str(slot_count),"t","t","default"], placement
            layout = r.sql("SELECT compaction_group_id,level_id,sstable_id,object_id,file_size "
                           "FROM rw_catalog.rw_hummock_sstables ORDER BY 1,2,3,4,5;",
                           run/"source-sst-fingerprint.txt")
            assert hashlib.sha256(layout.encode()).hexdigest() == seed_manifest["layout_sha256"]
            status = read_license_status()
            record("license-status-as-cloned", status)
            if status == dict(effective=False, reason="cpu_limit_exceeded", actual=12, limit=4):
                default_stmt = "ALTER SYSTEM SET license_key TO DEFAULT;"
                assert default_stmt in (repo / "e2e_test/error_ui/simple/license.slt").read_text().splitlines()
                r.sql(default_stmt, run / "apply-repository-default.txt")
                for _ in range(20):
                    status = read_license_status()
                    if status == LICENSE_EXPECTED:
                        break
                    time.sleep(0.25)
            record("license-status", status)
            setup, _ = query.split("CREATE MATERIALIZED VIEW", 1)
            r.sql(setup + "SELECT name, setting FROM pg_settings WHERE name LIKE '%parallelism%' ORDER BY name;",
                  run / "session-parallelism.txt")
            params = subprocess.run(r.SQL, input="SHOW PARAMETERS;", text=True, capture_output=True,
                                    env=r.ENV, cwd=repo, timeout=10, check=True)
            strategies = [line.split("|")[:2] for line in params.stdout.splitlines()
                          if line.startswith("adaptive_parallelism_strategy|")]
            record("system-parallelism", strategies)
            plan = r.sql(query.replace("CREATE MATERIALIZED VIEW", "EXPLAIN CREATE MATERIALIZED VIEW", 1),
                         run / "plan-actual.txt")
            providers = plan.count("StreamLocalityProvider")
            match_plan = (run / "plan-actual.txt").read_bytes() == (reference / "plan-actual.txt").read_bytes()
            if status != LICENSE_EXPECTED or providers != 6 or not match_plan:
                reason = dict(license=status, providers=providers, plan_matches_candidate=match_plan,
                              boot_seed=1346, create_mv_executed=False)
                record("preflight-blocked", reason)
                raise RuntimeError(f"Clean-main preflight: {reason}")
            assert "StreamHashJoin" in plan and "StreamHashAgg" in plan
            cn_env = subprocess.check_output(["ps", "eww", "-p", pid, "-o", "command="], text=True)
            assert "RW_STORAGE_IO_FASTRACE=false" in cn_env
            forbidden = ("RW_Q18_IO_DIAGNOSTIC", "RW_IO_DIAGNOSE_V2_DIR", "RW_TRACING_ENDPOINT",
                         "RW_HUMMOCK_ITER_PROFILE", "RW_PROFILE_PATH", "RUST_LOG_SPAN_EVENTS")
            assert not any(f"{key}=" in cn_env for key in forbidden)
            tracing_setting, = [line.split("|")[:2] for line in params.stdout.splitlines()
                                if line.startswith("enable_tracing|")]
            assert tracing_setting == ["enable_tracing", "false"], tracing_setting
            assert "opentelemetry tracing disabled" in startlog
            record("trace-controls", dict(fastrace=False, otlp_enabled=False, v2=False,
                                           targeted=False, broad=False, async_stack_trace="off"))
            (run/"cn-pid.txt").write_text(pid+"\n")
            assert "RW_Q18_SOURCE_BLOCKWISE=" not in cn_env
            assert "RW_HUMMOCK_ITER_PROFILE=" not in cn_env
            (run / "query.sql").write_text(query)
            record("run-controls", dict(source=base, pristine=True, patch_sha256=patch_sha, mode=mode, binary_sha256=digest(binary), seed=str(r.SEED),
                   seed_manifest=seed_manifest, config=parsed, actual_cn_threads=before_threads, locality_providers=providers,
                   compute_before=placement, logical_cpus=command_output("sysctl", "-n", "hw.logicalcpu"),
                   physical_cpus=command_output("sysctl", "-n", "hw.physicalcpu"),
                   advertised_slots=slot_count, mv_session_parallelism=parallelism,
                   source_prefetch="ColdRanges", locality_prefetch="ColdRanges", prefix_prefetch="ColdRanges", scheduler=scheduler, rust_log=r.ENV["RUST_LOG"], fastrace=False,
                   plan_matches_candidate=match_plan, multiget=multiget, targeted_trace=False))
            before = r.scrape()
            assert (b"object_store_read_scheduler_" in before) == scheduler
            (run / "before.prom").write_bytes(before)
            t0=time.monotonic()
            with (run/"ddl.txt").open("w") as ddl,gzip.open(run/"samples.jsonl.gz","wt") as samples:
                job=subprocess.Popen(r.SQL+["-f",str(run/"query.sql")],cwd=repo,env=r.ENV,
                                     stdout=ddl,stderr=subprocess.STDOUT)
                r.jobs.append(job)
                print(f"{arm}: launched Q18 psql={job.pid} CN={pid} locality={providers} mode={mode}",flush=True)
                startup=threading.Thread(target=first_window,args=(t0,pid),daemon=True)
                startup.start()
                sampling_stop=threading.Event()
                congestion=threading.Thread(target=sample_gauges,args=(t0,sampling_stop),daemon=True)
                congestion.start()
                next_progress=15
                while job.poll() is None:
                    if time.monotonic() - t0 > 3600:
                        raise TimeoutError("SF10 exceeded 60 minutes")
                    disk = shutil.disk_usage(repo).free
                    with (run/"disk-free.jsonl").open("a") as log:
                        print(json.dumps([time.monotonic()-t0,disk]),file=log)
                    if disk < 12 * 1024**3:
                        raise OSError(f"Stopping owned SF10 run: only {disk / 1024**3:.2f} GiB free")
                    try:
                        job.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        elapsed=time.monotonic()-t0
                        rss=int(command_output("ps","-p",pid,"-o","rss="))
                        data=capture(r.scrape())
                        print(json.dumps([elapsed,rss,data]),file=samples)
                        samples.flush()
                        depth_snapshot(elapsed,rss,data)
                        host(pid,round(elapsed,3))
                        if elapsed>=next_progress:
                            if next_progress in (15, 105):
                                try:
                                    instrument_catalog("during", require_vnodes=True)
                                except (AssertionError, OSError, RuntimeError, subprocess.SubprocessError) as exc:
                                    (run / "placement-during.error").write_text(f"{type(exc).__name__}: {exc}\n")
                            progress=r.sql("SHOW JOBS;",run/"jobs-latest.txt",10)
                            with (run/"jobs.jsonl").open("a") as log:
                                print(json.dumps([elapsed,progress]),file=log)
                            next_progress+=15
                elapsed=time.monotonic()-t0
                sampling_stop.set()
                congestion.join()
            assert job.returncode==0,run/"ddl.txt"
            assert "Falling back to regular backfill" not in (run/"ddl.txt").read_text()
            after=r.scrape()
            (run/"after.prom").write_bytes(after)
            after_threads=threads(pid,"after")
            host(pid,"after")
            startup.join()
            r.check_output()
            actual = r.sql(workers,run/"compute-after.txt")
            assert actual==placement,(actual,placement)
            instrument_catalog("after", require_vnodes=True)
            worker = parts[0]
            actors = r.sql("SELECT fragment_id, worker_id, count(*) "
                           "FROM rw_catalog.rw_actors GROUP BY 1,2 ORDER BY 1,2;",
                           run/"actors-by-fragment.txt")
            actor_rows = [row.split("|") for row in actors.splitlines()]
            assert actor_rows and all(row[1]==worker for row in actor_rows), actors
            job_actors = r.sql("SELECT a.fragment_id, a.worker_id, count(*) FROM rw_catalog.rw_actors a "
                               "JOIN rw_catalog.rw_fragments f ON a.fragment_id=f.fragment_id "
                               "JOIN rw_catalog.rw_materialized_views m ON f.table_id=m.id "
                               "WHERE m.name='tpch_q18' GROUP BY 1,2 ORDER BY 1,2;",
                               run/"q18-actors-by-fragment.txt")
            job_rows=[row.split("|") for row in job_actors.splitlines()]
            assert job_rows and all(row[1]==worker for row in job_rows),job_actors
            oracle_rows=len((run/"oracle.txt").read_text().splitlines())
            assert oracle_rows==100
            before_metrics = r.metrics(before)
            after_metrics = r.metrics(after)
            assert (b"object_store_read_scheduler_" in after) == scheduler
            assert (run / "query.sql").read_text() == query
            source_checkpoint = json.loads((run / "source-checkpoint.json").read_text())
            assert source_checkpoint["per_table"] == SOURCE_ROWS
            source_metrics = r.metrics("\n".join(source_checkpoint["metrics"]).encode())
            range_windows = {table: int(r.delta(before_metrics, source_metrics,
                             "state_store_sst_store_block_request_counts", type="prefetch_count", table_id=table))
                             for table in SOURCE_ROWS}
            blockwise_consumed = int(r.delta(before_metrics, after_metrics, "state_store_blockwise_prefetch_events", event="consumed"))
            # Range and ColdRanges both increment these per-table prefetch counters.
            assert all(range_windows.values()) and not blockwise_consumed, range_windows
            def range_prefetch_windows(table_id):
                return int(r.delta(before_metrics, after_metrics, "state_store_sst_store_block_request_counts",
                                   type="prefetch_count", table_id=table_id))
            locality_range = {table_id: range_prefetch_windows(table_id) for table_id in ("28","34","40","47","50","54")}
            prefix_range = {table_id: range_prefetch_windows(table_id) for table_id in ("32","38")}
            assert any(locality_range.values()), locality_range
            cold = "state_store_cold_range_prefetch_"
            cold_names = ("window_runs_count", "window_runs_sum", "read_bytes_count", "read_bytes_sum",
                          "gap_bytes_count", "gap_bytes_sum", "gap_blocks_sum", "hint_misses", "single_blocks", "budget_denied", "budget_shrunk")
            cold_counts = {
                phase: {name: int(r.delta(left, right, cold + name)) for name in cold_names}
                for phase, left, right in (("whole", before_metrics, after_metrics),
                                           ("through_source", before_metrics, source_metrics),
                                           ("after_source", source_metrics, after_metrics))
            }
            for phase in cold_counts.values():
                assert phase["window_runs_count"] > 0 and phase["read_bytes_count"] > 0, phase
                assert phase["hint_misses"] == 0, phase
            record("cold-range-counters", cold_counts)
            groups = r.delta(before_metrics, after_metrics, "object_store_read_scheduler_events", event="group_ok")
            assert groups > 0
            assert len(job_rows) == 14, job_actors
            fragment_actors = {row[0]: int(row[2]) for row in job_rows}
            assert fragment_actors == {str(i): 1 if i == 19 else 4 for i in range(19, 33)}, job_actors
            if parallelism == "fixed4" or slot_count == 4:
                assert max(fragment_actors.values()) == 4, job_actors
            meta_types = ("meta_total", "meta_miss", "meta_batch_ready", "meta_batch_retained",
                          "meta_batch_oversized", "meta_batch_budget_reject")
            meta = {table: {name: int(r.delta(before_metrics, after_metrics,
                    "state_store_sst_store_block_request_counts", type=name, table_id=table))
                    for name in meta_types} for table in ("27","32","38","42","53")}
            record("sst-meta-counters", meta)
            if (meta["38"]["meta_batch_ready"] > 0) != reuse:
                record("invalid-reuse", dict(reason="table 38 runtime hit counter mismatches config", expected=reuse, meta=meta))
                raise RuntimeError("Table 38 reuse runtime validation failed")
            batch_keys = {table: int(r.delta(before_metrics, after_metrics, "state_store_get_batch_keys_count", table_id=table))
                          for table in ("27", "53")}
            batch_total = int(r.delta(before_metrics, after_metrics, "state_store_get_batch_keys_count"))
            assert batch_total == sum(batch_keys.values()), batch_keys
            assert all((n > 0) == multiget for n in batch_keys.values()), batch_keys
            assert r.delta(before_metrics, after_metrics, "object_store_failure_count", type="read") == 0
            assert r.delta(before_metrics, after_metrics, "object_store_request_retry_count", type="read") == 0
            result = dict(arm=arm, multiget=multiget, batch_calls=batch_keys, meta_reuse=reuse,
                          scheduler_merged=int(r.delta(before_metrics, after_metrics, "object_store_read_scheduler_events", event="merged_requests")),
                          scheduler_inflight_reused=int(r.delta(before_metrics, after_metrics, "object_store_read_scheduler_events", event="inflight_reused")),
                          seconds=elapsed, source_rows=source_checkpoint["source_rows"],
                          source_prefetch_segments=range_windows, locality_prefetch_segments=locality_range,
                          join_prefix_prefetch_segments=prefix_range, blockwise_consumed=blockwise_consumed,
                          cold_range=cold_counts, oracle_rows=oracle_rows, oracle_matches=True,
                          compute_worker=placement, q18_actors=sum(int(row[2]) for row in job_rows),
                          q18_fragments=len(job_rows), fragment_actors=fragment_actors,
                          advertised_slots=slot_count, mv_session_parallelism=parallelism,
                          actual_cn_threads={"before": before_threads, "after": after_threads})
            record("result", result)
            print(json.dumps(result),flush=True)
        finally:
            r.stop()
    verify()

if __name__=="__main__":
    signal.signal(signal.SIGTERM,r.terminate)
    main_run()

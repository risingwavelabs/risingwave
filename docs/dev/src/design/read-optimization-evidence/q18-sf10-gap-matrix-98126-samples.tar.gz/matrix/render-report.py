"""Render the full six-run report after validation; application source is unmodified."""
from pathlib import Path
import json
from statistics import median
s=Path(__file__).resolve().parent
bundle=json.loads((s/'matrix-results.json').read_text());runs=bundle['runs']
assert len(runs)==6
lookup={r['arm']:r for r in runs}
for r in runs:
 assert r['source_checkpoint_after_first_provider_s']<0
 assert r['oracle_matches'] and r['services_and_test_clone_cleaned_up']
 for ph in r['phase'].values():
  assert ph['failures']==0 and ph['retries']==0
 assert r['phase']['whole']['prefetch_buffer_sampled_peak_bytes']<=4096*2**20
lines=['# SF10 Q18 gap matrix after the ColdRanges budget fix', '',
'## Findings', '',
'All three paired source scans improve with the 64 KiB gap. GET reductions are 7.96%, 4.37% and 12.49%; physical byte increases are 0.53%, 0.13% and 0.71%. Source checkpoints improve by 5.01, 11.00 and 4.00 seconds. Cohort-median physical mean latency decreases from 3.927 to 3.368 ms, while source physical p99/p99.9 stay in the 32/64 ms buckets and caller p99/p99.9 stay in the 378.77/568.15 ms buckets. The consistent result is fewer source GETs and modest source-time improvement in this local MinIO setup; there is no demonstrated tail-latency improvement.', '',
'All six runs have zero budget_denied and zero budget_shrunk over the whole query. Sampled charged peaks range from 3.752 to 3.773 GiB, and whole CN RSS peaks range from 5.272 to 5.721 GiB. This removes the observed budget-rejection/per-block fallback at a 4 GiB configuration. Genuine one-block prefetch segments still exist, especially for HashJoin prefixes; their presence is not evidence of budget fallback. No shrink branch was needed here.', '',
'CREATE MV differences are -145.22, -67.62 and +131.97 seconds, so these runs do not establish a stable end-to-end gap-policy speedup. In pair 3 the 24-to-22 HashJoin interval increases from 111.00 to 227.00 seconds, CN CPU from 602 to 966 aggregate seconds, and table-38 candidate checks from 44.91M to 194.77M, while aggregate GET service decreases from 49.03 to 43.40 seconds. That interval explains 116 of the 132 added seconds and identifies generated-SST candidate/CPU work as the main observed regression mechanism, rather than slower physical reads. Pair 1 shows the reverse candidate-work difference and a large wall-time gain.', '',
'G saturation is observed during startup; none of the later one-second samples reaches G128. Only two post-startup samples across the six runs reach P32. These samples do not exclude short unsampled bursts. The startup admission tail remains and this gap experiment does not fix it.', '',
'## Scope and controls', '',
'Source is exactly `98126f898412f675ebdd406c35cd273f4972dd2b`, without application patches. All six measurements use the same release executable, SHA-256 `668dda3604d17656f97ad1c0fc2e9821aca92bc6e79d08486520b5c84f8ffcff`. Build uses opt-level 3, application debug assertions off, `split-debuginfo=unpacked`, incremental off and the existing license-crate debug-assertions test configuration. Cargo manifests retain the exact build identity.', '',
'Each arm uses `risedev d full` through the shared host-exclusion guard and a new disposable APFS clone of immutable cold seed v1346. There are six LocalityProviders, 53 actors, fixed4 SQL parallelism, 12 advertised CN slots, eight configured streaming runtime workers and six dedicated IO workers. G128/P32/B16, N16, the 1 MiB read cap, 4 GiB prefetch budget, MultiGet, metadata reuse and in-flight reuse are fixed. Source StreamScan, LocalityProvider and HashJoin prefix scans use ColdRanges. Foyer file cache and tracing/profiling are off. The backend is local MinIO.', '',
'The workload is the existing locality-backfill Q18 variant with `HAVING sum(l_quantity) > 1` and a 100-row top-N result, not the unmodified TPC-H threshold. Customer has 1.5M rows, orders 15M rows and lineitem 59,986,052 rows; the plan scans lineitem twice, for 136,472,104 snapshot rows. The only compared TOML field is `max_gap_bytes = 0` versus `65536`. The order is 0 / 64 KiB / 64 KiB / 0 / 0 / 64 KiB. Every run validates the same source SST fingerprint, source row counts, SQL and plan hashes, executable, effective settings, worker configuration and the 100-row output oracle. Cold means fresh RW/Foyer process state from the durable seed; host OS page cache is not purged. Intermediate state SSTs are generated during each run and are not frozen.', '',
'## Runs and paired differences', '',(s/'matrix-comparison.md').read_text(),
'## IO latency and queueing', '',
'| Arm | Source physical mean ms | Physical p99 / p99.9 ms | Source caller mean ms | Caller p99 / p99.9 ms | After 5s admission mean / p99 ms | After 5s dispatch mean / p99 ms |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in runs:
 ph=r['phase']['through_source']['latency_ms'];a=r['after_startup_latency_ms'];p=ph['physical_get'];c=ph['all_object_reads'];adm=a['admission'];d=a['dispatch']
 lines.append(f"| {r['arm']} | {p['mean']:.3f} | {p['percentile_bucket_upper']['99']:.2f} / {p['percentile_bucket_upper']['99.9']:.2f} | {c['mean']:.3f} | {c['percentile_bucket_upper']['99']:.2f} / {c['percentile_bucket_upper']['99.9']:.2f} | {adm['mean']:.4f} / {adm['percentile_bucket_upper']['99']:.2f} | {d['mean']:.4f} / {d['percentile_bucket_upper']['99']:.2f} |")
lines += ['', 'Percentiles are histogram upper bucket bounds, not exact quantiles. The caller metric includes prefetch and ordinary ObjectStore callers; it is not a demand-only or iterator-consumption latency metric. The after-five-second columns cover the remainder of the query, not only source scans. Aggregate physical service sums parallel GET durations and is not elapsed query time.', '', '## Prefetch accounting and process memory', '',
'The charge is an estimate of live prefetch-owned memory, not a CN RSS cap. The fix reserves direct encoded buffers and one decode peak, actual pinned cache block weights, and independent bounds for concurrently completing cache/singleton results. Smaller prefixes can be attempted before single-block demand fallback. A zero `budget_shrunk` result means that branch was not exercised in this SF10 run; permanent fixed-budget unit tests in the selected commit cover it.', '',
'![Source-stage memory curves](q18-sf10-gap-matrix-98126-source-memory.png)', '',
'Curves retain startup 0.1-second and later one-second gauge samples. Charged and RSS peaks are sampled. Full source metrics reuse the one-second HTTP scrape; source completion is bracketed by the last incomplete and first complete row-count observation. Every source checkpoint in this matrix precedes the first LocalityProvider startup, so the historical provider-startup checkpoint contamination is absent here.', '',
'## Elapsed-time attribution', '',
(s/'operator-phase-attribution.md').read_text(),
'## Historical 312.94 MiB versus 79.91 MiB accounting', '',
'This section reads the existing `0bb0df4acf` / 16 GiB gap pair only. It does not rerun that historical workload or mix it into the six-run cohorts.', '',
(s/'historical-byte-ledger.md').read_text(),
'The identity is **312.936045 = 222.851888 + 79.908559 + 10.175598 MiB**. Only 79.908559 MiB is directly counted scheduler gap overread. The 222.851888 MiB term is the change in declared direct-prefetch spans. The remaining 10.175598 MiB is a derived residual combining other reads, overlap/reuse and planning/completion boundaries; it is not an independently measured metadata byte total.', '',
'The historical gap64 source checkpoint was at 85.96 s, after the first provider at 83.09 s. Its last full pre-provider scrape was at 80.92 s with 99.50% source rows complete. The final 498 GETs / 197.71 MiB physical and 198.56 MiB declared direct-prefetch bytes mix the source tail with provider startup. The historical source scrape omitted logical requested-byte series, so an exact source-only logical-byte attribution cannot be recovered. Whole-query before/after scrapes retain bounded logical bytes. Raw historical ledger JSON records counts, cancellation/retry outcomes and these coverage limits. The new matrix fixes this sampling omission and checkpoint resolution.', '',
'## Evidence and cleanup', '',
'`q18-sf10-gap-matrix-98126.json` contains all per-run phase summaries and controls. `q18-sf10-gap-matrix-98126-samples.tar.gz` contains the per-run raw metric snapshots, one-second source samples, memory curves, row progress, host-load and disk samples, logs, plans, configurations, identity/placement checks, and cleanup records. Supporting analysis and runner scripts are retained with the archive. No application code or license source hook is committed by this benchmark report. Owned services and disposable seed clones are removed after each arm; the reusable cold seed and staged release executable are retained.', '']
(s/'round-summary.md').write_text('\n'.join(lines))
print(s/'round-summary.md')

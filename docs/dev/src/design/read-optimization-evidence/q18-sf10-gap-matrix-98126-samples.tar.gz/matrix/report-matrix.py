"""Render per-run and paired Q18 gap/memory observations from retained summaries."""
from pathlib import Path
import json
from statistics import median

s=Path(__file__).resolve().parent
plan=json.loads((s/'matrix-plan.json').read_text())
items=[]
for name in plan['order']:
 path=s/name/'matrix-analysis.json'
 if path.is_file():items.append(json.loads(path.read_text()))
if not items:raise SystemExit('No completed arms yet.')
ref=items[0]
for r in items:
 for k in ('source_commit','source_diff_sha256','binary_sha256','source_sst_fingerprint_sha256','catalog_plan_sha256','query_sha256',
           'actual_runtime_workers_before','source_rows_per_table','advertised_slots','q18_actors','locality_providers','oracle_rows','trace_enabled'):
  assert r[k]==ref[k],(r['arm'],k)
 a=json.loads(json.dumps(ref['settings']))
 a['storage']['object_store']['read_scheduler']['max_gap_bytes']=r['settings']['storage']['object_store']['read_scheduler']['max_gap_bytes']
 assert a==r['settings']
 assert r['oracle_matches'] and r['services_and_test_clone_cleaned_up']
assert all(r['settings']['storage']['prefetch_buffer_capacity_mb']==4096 for r in items)

def ph(r,name='whole'):return r['phase'][name]
def tail(r,metric,q,phase='through_source'):
 return ph(r,phase)['latency_ms'][metric]['percentile_bucket_upper'][q]
rows=['| Arm | Source complete midpoint s | Source checkpoint s | MV s | Source GETs | Source GiB | Whole GETs | Whole GiB | Source denied / shrunk | Source budget peak MiB | Source RSS peak MiB | Whole RSS peak MiB |',
      '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: |']
for r in items:
 p=ph(r,'through_source');w=ph(r);c=p['prefetch_budget_counters'];br=r['source_complete_bracket_s']
 rows.append(f"| {r['arm']} | {sum(br)/2:.2f} | {r['source_checkpoint_s']:.2f} | {w['wall_time_s']:.2f} | {p['gets']:,} | {p['read_bytes']/2**30:.3f} | {w['gets']:,} | {w['read_bytes']/2**30:.3f} | {c['budget_denied']:,} / {c['budget_shrunk']:,} | {p['prefetch_buffer_sampled_peak_bytes']/2**20:.1f} | {p['cn_rss_sampled_peak_bytes']/2**20:.1f} | {r['peak_cn_rss_mib']:.1f} |")
rows+=['','| Metric (cohort median) | Gap 0 | Gap 64 KiB |','| --- | ---: | ---: |']
groups={gap:[r for r in items if r['cohort']==gap] for gap in ('gap0','gap64k')}
metrics=[('Source completion midpoint, s',lambda r:sum(r['source_complete_bracket_s'])/2,'.2f'),
 ('Source checkpoint, s',lambda r:r['source_checkpoint_s'],'.2f'),
 ('MV wall, s',lambda r:ph(r)['wall_time_s'],'.2f'),
 ('Source GETs',lambda r:ph(r,'through_source')['gets'],',.0f'),
 ('Source GiB',lambda r:ph(r,'through_source')['read_bytes']/2**30,'.3f'),
 ('Whole GETs',lambda r:ph(r)['gets'],',.0f'),
 ('Whole GiB',lambda r:ph(r)['read_bytes']/2**30,'.3f'),
 ('Source denied',lambda r:ph(r,'through_source')['prefetch_budget_counters']['budget_denied'],',.0f'),
 ('Source shrunk',lambda r:ph(r,'through_source')['prefetch_budget_counters']['budget_shrunk'],',.0f'),
 ('Source charged peak MiB',lambda r:ph(r,'through_source')['prefetch_buffer_sampled_peak_bytes']/2**20,'.1f'),
 ('Source CN RSS peak MiB',lambda r:ph(r,'through_source')['cn_rss_sampled_peak_bytes']/2**20,'.1f'),
 ('Whole CN RSS peak MiB',lambda r:r['peak_cn_rss_mib'],'.1f'),
 ('Source physical mean ms',lambda r:ph(r,'through_source')['latency_ms']['physical_get']['mean'],'.3f'),
 ('Source physical p99 ms',lambda r:tail(r,'physical_get','99'),'.2f'),
 ('Source physical p99.9 ms',lambda r:tail(r,'physical_get','99.9'),'.2f'),
 ('Source caller p99 ms',lambda r:tail(r,'all_object_reads','99'),'.2f'),
 ('Source caller p99.9 ms',lambda r:tail(r,'all_object_reads','99.9'),'.2f'),
 ('Source overread MiB',lambda r:ph(r,'through_source')['overread_bytes']/2**20,'.3f'),
 ('Source merged members',lambda r:ph(r,'through_source')['scheduler_event_counts']['merged_requests'],',.0f'),
 ('Source bounded requested MiB',lambda r:sum(x['bytes'] for x in ph(r,'through_source')['logical_bounded_requested_bytes'].values())/2**20,'.3f')]
for label,getter,fmt in metrics:
 values=[format(median(getter(r) for r in groups[k]),fmt) if groups[k] else '—' for k in ('gap0','gap64k')]
 rows.append('| '+label+' | '+' | '.join(values)+' |')
rows+=['','| Pair (64 KiB minus 0) | Source checkpoint s | Source completion midpoint s | MV s | Source GETs | Source MiB | Whole GETs | Whole MiB |',
       '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
pairs=[]
for i in (1,2,3):
 lookup={r['cohort']:r for r in items if r['round']==i}
 if len(lookup)!=2:continue
 a,b=(lookup[k] for k in ('gap0','gap64k'))
 d=dict(round=i,source_checkpoint_s=b['source_checkpoint_s']-a['source_checkpoint_s'],
  source_completion_midpoint_s=(sum(b['source_complete_bracket_s'])-sum(a['source_complete_bracket_s']))/2,
  mv_s=ph(b)['wall_time_s']-ph(a)['wall_time_s'],source_gets=ph(b,'through_source')['gets']-ph(a,'through_source')['gets'],
  source_bytes=ph(b,'through_source')['read_bytes']-ph(a,'through_source')['read_bytes'],
  whole_gets=ph(b)['gets']-ph(a)['gets'],whole_bytes=ph(b)['read_bytes']-ph(a)['read_bytes'])
 pairs.append(d)
 rows.append(f"| {i} | {d['source_checkpoint_s']:+.2f} | {d['source_completion_midpoint_s']:+.2f} | {d['mv_s']:+.2f} | {d['source_gets']:+,} | {d['source_bytes']/2**20:+.3f} | {d['whole_gets']:+,} | {d['whole_bytes']/2**20:+.3f} |")
rows+=['','Percentiles are histogram bucket upper bounds. All RSS/charged peaks are sampled. Each source checkpoint is the first completed full one-second source scrape.']
(s/'matrix-comparison.md').write_text('\n'.join(rows)+'\n')
(s/'matrix-results.json').write_text(json.dumps(dict(plan=plan,runs=items,paired_differences=pairs),indent=2,allow_nan=False)+'\n')
print('\n'.join(rows))

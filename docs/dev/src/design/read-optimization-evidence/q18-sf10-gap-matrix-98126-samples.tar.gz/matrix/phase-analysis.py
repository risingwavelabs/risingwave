"""Separate operator work from gap IO using completed matrix evidence."""
from pathlib import Path
import json
s=Path(__file__).resolve().parent
plan=json.loads((s/'matrix-plan.json').read_text())
items=[json.loads((s/a/'matrix-analysis.json').read_text()) for a in plan['order'] if (s/a/'matrix-analysis.json').is_file()]
lines=['# Operator-phase attribution', '', 'Elapsed differences after source scanning include changes in generated SST candidate work. These counters locate the difference but cannot isolate an end-to-end speedup from the gap policy.', '', '| Arm | Interval | Wall s | CN CPU s | Physical GET service s | GETs | MiB | SST candidates table 38 M | SST candidates table 32 M |', '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in items:
 for name in ('through_source','first_to_24','24_to_22','22_to_20','agg20_to_merge'):
  p=r['phase'][name];c=p['sst_candidate_checks']
  lines.append(f"| {r['arm']} | {name} | {p['wall_time_s']:.2f} | {p['cpu_time_s']:.0f} | {p['latency_ms']['physical_get']['sum']/1000:.2f} | {p['gets']:,} | {p['read_bytes']/2**20:.2f} | {c.get('38',0)/1e6:.2f} | {c.get('32',0)/1e6:.2f} |")
lines+=['', 'Physical GET service is an aggregate of parallel reads and cannot be subtracted from wall time. Phase boundaries use provider logs, while counters use the preceding full scrape. SST candidate counters are CN-wide for the named table. Source counters use the first source-complete one-second scrape.', '']
(s/'operator-phase-attribution.md').write_text('\n'.join(lines))
print('\n'.join(lines))

# SF10 Q18 latest-memory-fix gap matrix

The user requested three runs per gap, memory budget/denial/shrink/RSS curves,
and historical 312.94 MiB versus 79.91 MiB read-byte accounting.
The user explicitly selected commit 98126f898412f675ebdd406c35cd273f4972dd2b and 4 GiB.
Keep six I/O workers, eight streaming workers, G128/P32/B16, N16/1 MiB,
fixed4 on 12 advertised slots, six LocalityProviders, the immutable v1346
source seed, no Foyer file cache, and trace off.

Latest suite pointer is target/locality-tpch-q18/latest-gap-matrix-suite.txt.
The build is guarded, release with unpacked debug info and the existing
license-crate debug-assertions test hook. Main source worktree is untouched.

Build process exec session 61663 completed successfully. Active matrix process exec session is 20219.
The first matrix driver 30106 stopped on an offline sorting error after p1-gap0 passed.
The duplicate-timestamp sort was fixed, p1-gap0 was analyzed from its retained data,
and the runner resumed remaining arms without rerunning p1-gap0.
The matrix waits for the same shared local-test lock while the build runs.
Run order is p1-gap0, p1-gap64k, p2-gap64k, p2-gap0, p3-gap0, p3-gap64k.
run-matrix.sh stops on an unexpected failure; inspect each arm-driver.log,
arm-analysis.log and matrix-driver.log before continuing.

A full source snapshot is now saved on each 1 s sample until completion,
reusing the existing gauge HTTP scrape. It includes logical requested-byte
histograms, block-cache events, budget_shrunk and budget_denied. This reduces
the historical five-second checkpoint contamination from provider startup.
source-samples.jsonl.gz and memory-curve.json retain the samples.
collect/analyze and export-runs timelines include these full source points.

The source checkpoint writer has a lock because main/startup/gauge threads
can all observe completion. All application code remains at the selected commit.

historical-byte-ledger.json and .md reconcile old files without rerunning.
Physical delta 312.936045 MiB = declared direct-prefetch delta 222.851888 MiB
+ explicit scheduler gap 79.908559 MiB + residual delta 10.175598 MiB.
The old source sampler omitted logical-request byte series; whole before/after
scrapes have bounded requested bytes. The gap64 last pre-provider full scrape
has 99.50% source rows; its remaining 498 GETs / 197.71 MiB contain both source
tail and provider startup, with 198.56 MiB of declared direct prefetch added.
Do not pretend the missing per-source logical byte breakdown is measured.

Pending after the six arms complete
- Validate identical binary, source fingerprint, plan and configuration delta.
- Report individual runs and paired differences with median/range.
- Analyze source milestone versus actual 1 s source-completion brackets.
- Report source/whole GET, bytes, tails, budget counters and memory curves.
- Explain material elapsed differences with operator CPU and SST candidate work.
- Save standalone report and raw evidence, push only evidence on the existing
  li0k/q18-cold-ranges-fixed-io6-20261118 branch. Preserve newer remote commits.
- Clean owned services/data/build cache and test worktree only after verification.

Progress: p1-gap0 passed in 679.04 s. Source checkpoint 85.01 s, 42,941 GETs,
12.357 GiB, denied=0, shrunk=0, charged peak 3.7516 GiB, CN RSS peak 5.7042 GiB.
The p1-gap64k run is active; its source checkpoint is about 80 s, 39,525 GETs,
12.423 GiB, denied=0, shrunk=0. Full source bytes are now captured every second.

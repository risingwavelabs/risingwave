"""Export comparable SF10 Q18 summaries and sampled queue depths for the experiment record."""
from collections import defaultdict
import gzip
import hashlib
import json
from math import isfinite
from pathlib import Path

from analyze import delta, histogram, load, metrics, parse_lines

ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT.parent / "sf10-q18-762f4c7ec4-repeat.D4kEpvF6"
SCHED = "object_store_read_scheduler_"
READ = {"type": "read"}
LATENCIES = {
    "physical_get": ("object_store_operation_latency", READ),
    "scheduled_logical": ("object_store_read_request_duration_seconds", {"route": "scheduled"}),
    "admission": (SCHED + "admission_duration_seconds", {}),
    "dispatch": (SCHED + "queue_duration_seconds", {}),
    "p_reserved_to_first_poll": (SCHED + "physical_duration_seconds", {"stage": "reservation_to_start"}),
    "scheduler_backend_service": (SCHED + "physical_duration_seconds", {"stage": "group"}),
    "consumer_wait": ("state_store_blockwise_prefetch_wait_duration_seconds", {}),
}
EVENTS = ("submitted_batch_members", "sealed_batch_single", "sealed_batch_multiple", "merged_requests",
          "inflight_reused", "group_ok", "group_error", "group_read_error", "fallback_single",
          "sealed_batch_empty", "batch_expired")
ROUTES = ("scheduled", "oversized", "unbounded", "empty_range", "direct")
SOURCE = "stream_snapshot_backfill_consume_snapshot_row_count"
DEPTH = {
    (SCHED + "groups", "admitted"): "g_admitted",
    (SCHED + "groups", "queued"): "g_queued",
    (SCHED + "groups", "ready"): "g_ready",
    (SCHED + "in_flight", ""): "p_backend_started",
    (SCHED + "reserved", ""): "p_reserved_before_backend_poll",
    (SCHED + "waiting", ""): "logical_waiting_for_admission",
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read_hist(left, right, metric, labels, scale=1, thresholds=()):
    h = histogram(left, right, metric, **labels)
    if not h["count"]:
        return None
    bins = sorted((float(le) * scale, n) for le, n in h["populated_buckets"].items())
    assert sum(n for _, n in bins) == h["count"], metric
    percentiles = {}
    cumulative = 0
    for bound, n in bins:
        cumulative += n
        for percentile in (50, 95, 99, 99.9):
            if cumulative >= h["count"] * percentile / 100:
                percentiles.setdefault(str(percentile), bound if isfinite(bound) else None)
    available_boundaries = [
        float(dict(series)["le"]) * scale
        for name, series in right
        if name == metric + "_bucket" and labels.items() <= dict(series).items()
    ]
    thresholds = [t for t in thresholds if any(abs(t - le) < 1e-8 for le in available_boundaries)]
    return dict(sample_count=h["count"], sum=h["sum"] * scale, mean=h["mean"] * scale,
                percentile_bucket_upper=percentiles,
                noncumulative_buckets=[[bound if isfinite(bound) else "+Inf", n] for bound, n in bins],
                count_above={str(t): sum(n for bound, n in bins if bound > t + 1e-9) for t in thresholds})

def latency(left, right, metric, labels):
    thresholds = (8, 16, 32, 64, 128, 256) if metric == "object_store_operation_latency" else (5.12, 20.48, 81.92, 327.68)
    return read_hist(left, right, metric, labels, 1000, thresholds)

def read_depths(rows, cutoff, first):
    peaks = defaultdict(int)
    occupancy = defaultdict(lambda: {"samples": 0, "g_at_capacity": 0, "p_at_capacity": 0})
    startup = []
    for start, end, current in rows:
        data = {}
        for (metric, labels), count in current.items():
            if key := DEPTH.get((metric, dict(labels).get("stage", ""))):
                data[key] = data.get(key, 0) + int(count)
        if not data:
            continue
        phase = "first_five_seconds" if end <= 5 else ("through_source_after_five_seconds" if end <= cutoff else "after_source")
        record = occupancy[phase]
        record["samples"] += 1
        record["g_at_capacity"] += data.get("g_admitted", 0) >= 128
        record["p_at_capacity"] += data.get("p_backend_started", 0) + data.get("p_reserved_before_backend_poll", 0) >= 32
        for key, value in data.items():
            peaks[key] = max(peaks[key], value)
        if end <= 5:
            admit_n = int(delta(first, current, SCHED + "admission_duration_seconds_count"))
            admit_le = int(delta(first, current, SCHED + "admission_duration_seconds_bucket", le="0.32768"))
            startup.append(dict(scrape_elapsed_start_s=round(start, 4), scrape_elapsed_end_s=round(end, 4),
                                depth=data, completed_admission_observations=admit_n,
                                completed_admission_observations_above_327_68ms=admit_n-admit_le,
                                physical_gets=int(delta(first, current, "object_store_operation_bytes_count", **READ))))
    return dict(sampled_peaks=dict(peaks), sample_counts_by_interval=dict(occupancy), first_five_seconds=startup)

def summarize_phase(left, right, name, bounds):
    latencies = {key: latency(left, right, m, labels) for key, (m, labels) in LATENCIES.items()
                 if key != "scheduled_logical" or name == "whole"}
    groups = read_hist(left, right, SCHED + "group_size", {})
    sizes = read_hist(left, right, "object_store_operation_bytes", READ, thresholds=(64 * 1024,))
    gets = int(delta(left, right, "object_store_operation_bytes_count", **READ))
    assert sizes and sizes["sample_count"] == gets
    physical_samples = latencies["physical_get"]["sample_count"] if latencies["physical_get"] else 0
    if name == "whole":
        assert physical_samples == gets, (name, bounds, physical_samples, gets)
    def count(metric, **labels):
        return int(delta(left, right, metric, **labels))
    return {
        "wall_time_s": bounds[0],
        "elapsed_phase_bounds_s": bounds[1],
        "elapsed_scrape_bounds_s": bounds[2],
        "cpu_time_s": delta(left, right, "process_cpu_seconds_total"),
        "gets": gets,
        "read_bytes": count("object_store_operation_bytes_sum", **READ),
        "get_latency_samples_minus_successful_gets": physical_samples - gets,
        "gets_at_most_64kib": count("object_store_operation_bytes_bucket", le="65536", **READ),
        "get_bytes_distribution": sizes,
        "latency_ms": latencies,
        "request_routes": {route: count("object_store_read_requests", route=route) for route in ROUTES},
        "scheduled_group_members": groups,
        "single_member_groups": next((n for le, n in groups["noncumulative_buckets"] if le == 1), 0) if groups else None,
        "scheduler_event_counts": {event: count(SCHED + "events", event=event) for event in EVENTS},
        "overread_bytes": count(SCHED + "overread_bytes"),
        "failures": count("object_store_failure_count", **READ),
        "retries": count("object_store_request_retry_count", **READ),
        "blockwise_consumed": count("state_store_blockwise_prefetch_events", event="consumed"),
        "sst_candidate_checks": {
            table: sum(count("state_store_sst_store_block_request_counts", table_id=table, type=kind)
                       for kind in ("meta_total", "meta_batch_ready"))
            for table in ("32", "38")
        },
    }

def summarize(run, cohort, index):
    a = load(run / "analysis.json")
    c = a["controls"]
    result = a["result"]
    wall = result["seconds"]
    first, last = (metrics((run / f).read_bytes()) for f in ("before.prom", "after.prom"))
    cutoff = load(run / "source-checkpoint.json")
    ending = cutoff["elapsed_s"]
    source = parse_lines(cutoff["metrics"])
    assert sum(cutoff["per_table"].values()) == 136472104
    assert result["q18_actors"] == 53 and result["oracle_rows"] == 100 and result["oracle_matches"]
    timeline = {0: first, wall: last, ending: source}
    if cohort != "clean_main":
        with gzip.open(run / "samples.jsonl.gz", "rt") as samples:
            timeline.update((t, parse_lines(raw)) for t, _, raw in map(json.loads, samples))
    if (run / "source-samples.jsonl.gz").is_file():
        with gzip.open(run / "source-samples.jsonl.gz", "rt") as source_samples:
            timeline.update((t, parse_lines(raw)) for t, _, raw in map(json.loads, source_samples))
    startup = [(t0, t1, parse_lines(raw)) for t0, t1, raw, *_ in map(json.loads, (run / "startup-samples.jsonl").open())
               if t1 <= 5 and isinstance(raw, list)]
    t0, t1, checkpoint = startup[-1]
    phase_ranges = {
        "whole": (wall, [0, wall], [0, wall]),
        "through_source": (ending, [0, ending], [0, ending]),
        "after_source": (wall - ending, [ending, wall], [ending, wall]),
    }
    if cohort != "clean_main":
        for phase in ("first_to_24", "24_to_22", "22_to_20", "agg20_to_merge"):
            b = a["phases"][phase]
            phase_ranges[phase] = (b["wall_s"], b["log_boundaries_s"], b["scrape_boundaries_s"])
    phases = {name: summarize_phase(*(timeline[t] for t in bounds[2]), name, bounds) for name, bounds in phase_ranges.items()}
    assert phases["whole"]["gets"] == phases["through_source"]["gets"] + phases["after_source"]["gets"]
    assert all(v["failures"] == v["retries"] == 0 for v in phases.values())
    samples = [(t0, t1, parse_lines(raw)) for t0, t1, raw, *_ in map(json.loads, (run / "congestion.jsonl").open())
               if isinstance(raw, list)]
    assert (run / "cleanup.txt").is_file()
    return {
        "cohort": cohort,
        "round": index,
        "source_commit": c["source"],
        "source_diff_sha256": c.get("patch_sha256"),
        "binary_sha256": c["binary_sha256"],
        "settings": c["config"],
        "advertised_slots": c.get("advertised_slots", 4),
        "actual_runtime_workers_before": {k: c["actual_cn_threads"].get(k, 0)
                                          for k in ("rw-read-io", "rw-streaming", "rw-batch", "rw-compaction")},
        "source_rows_per_table": cutoff["per_table"],
        "source_complete_bracket_s": a.get("source_bracket_s", a.get("source_done_interval_s")),
        "source_checkpoint_s": ending,
        "catalog_plan_sha256": digest(run / "plan-actual.txt"),
        "source_sst_fingerprint_sha256": digest(run / "source-sst-fingerprint.txt"),
        "query_sha256": digest(run / "query.sql"),
        "primary_key_check": "NoCheck",
        "trace_enabled": False,
        "locality_providers": c["locality_providers"],
        "q18_actors": result["q18_actors"],
        "oracle_rows": result["oracle_rows"],
        "oracle_matches": result["oracle_matches"],
        "peak_cn_rss_mib": a["rss_peak_mib"] if cohort == "clean_main" else a["phases"]["whole"]["peak_rss_mib"],
        "min_free_gib": a.get("min_free_gib"),
        "startup_boundary_scrape_s": [t0, t1],
        "depths": read_depths(startup + samples, ending, first),
        "startup_latency_ms": {k: latency(first, checkpoint, *LATENCIES[k]) for k in ("physical_get", "admission", "dispatch")},
        "after_startup_latency_ms": {k: latency(checkpoint, last, *LATENCIES[k]) for k in ("physical_get", "admission", "dispatch")},
        "phase": phases,
        "operator_milestones_s": a["logs"].get("milestones_s"),
        "table38_24_to_22": a.get("table38_24_to_22"),
        "multiget_batch_calls_by_table": result.get("batch_calls"),
        "services_and_test_clone_cleaned_up": True,
    }

def completed_new_arm(n):
    candidates = [p for p in ROOT.glob(f"p{n}-on*") if (p / "result.json").is_file() and (p / "cleanup.txt").is_file()]
    arm, = candidates
    return arm

def main():
    previous = [
        ROOT.parent / "sf10-q18-762f4c7ec4-all-on.htmo3GoP" / "p1-on",
        REFERENCE.with_name(REFERENCE.name + "-run2") / "p1-on",
        REFERENCE.with_name(REFERENCE.name + "-run3") / "p1-on",
    ]
    cohorts = {
        "clean_main": [ROOT.parent / "sf10-q18-paired" / f"p{i}-a" for i in (1, 2, 3)],
        "previous_all_on": previous,
        "simplified_all_on": [completed_new_arm(i) for i in (1, 2, 3)],
    }
    runs = [summarize(p, cohort, i) for cohort, arms in cohorts.items() for i, p in enumerate(arms, 1)]
    for field in ("query_sha256", "catalog_plan_sha256", "source_sst_fingerprint_sha256"):
        assert len({r[field] for r in runs}) == 1, field
    ref = None
    for cohort, arms in cohorts.items():
        for arm in arms:
            rows = sorted((arm / "oracle.txt").read_text().splitlines())
            if ref is None:
                ref = rows
            assert rows == ref, (cohort, arm.name)
    new = [r for r in runs if r["cohort"] == "simplified_all_on"]
    assert len({r["binary_sha256"] for r in new}) == 1 and len({r["source_commit"] for r in new}) == 1
    for group in (runs[3:6], new):
        assert all(x["settings"] == group[0]["settings"] for x in group)
        assert all(x["actual_runtime_workers_before"]["rw-read-io"] == 2 for x in group)
    data = {
        "schema_version": 1,
        "experiment": "TPC-H SF10 Q18 Locality Backfill on macOS ARM64 with RiseDev full and local MinIO",
        "seed_version": 1346,
        "measurement": "Foreground CREATE MATERIALIZED VIEW. Time values are relative to that measurement unless noted.",
        "histograms": "Noncumulative buckets. Percentiles report bucket upper bounds. A missing series or unbounded percentile is null.",
        "clean_main": "Historical Range 4 GiB endpoint. Four advertised slots, fixed4 and eight streaming workers.",
        "previous_all_on": "Historical two-worker all-on build with a 100 us batch timer and the scheduler background runtime patch.",
        "simplified_all_on": "Three samples of the same release binary. Two-worker all-on build with the branch one-yield plug.",
        "label_notes": [
            "Wins or regressions against historical cohorts can include host or intermediate-layout variation.",
            "Nonempty seal counters changed meaning between releases. Physical group-size distributions are directly comparable.",
            "Logical scheduled latency includes demand and speculative work. The separate consumer wait histogram covers consumed Blockwise prefetch.",
            "Phase counters are CN-wide. Source-progress checkpoints are sampled and can include concurrent operators.",
            "Separate Prometheus metric families can differ by a few in-flight observations at a phase boundary. The whole-run count reconciles; each phase reports its measured difference.",
        ],
        "runs": runs,
    }
    (ROOT / "q18-sf10-scheduler-simplify.json").write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")

if __name__ == "__main__":
    main()

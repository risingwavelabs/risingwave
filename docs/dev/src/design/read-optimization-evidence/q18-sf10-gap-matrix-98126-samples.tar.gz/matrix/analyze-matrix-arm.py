"""Analyze one guarded, same-release Q18 gap arm including the 1 s source endpoint."""
from pathlib import Path
import gzip
import importlib.util
import json
import re
import sys

from analyze import collect, delta, metrics, parse_lines

suite = Path(__file__).resolve().parent
arm = suite / sys.argv[1]
assert re.fullmatch(r"p[123]-gap(?:0|64k)(?:-retry\d+)?",arm.name)
assert (arm/"cleanup.txt").is_file()
spec=importlib.util.spec_from_file_location("matrix_export",suite/"export-runs.py")
export=importlib.util.module_from_spec(spec)
spec.loader.exec_module(export)
analysis=collect(arm)
(arm/"analysis.json").write_text(json.dumps(analysis,indent=2)+"\n")
gap=65536 if "-gap64k" in arm.name else 0
round_number=int(arm.name[1])
run=export.summarize(arm,"gap64k" if gap else "gap0",round_number)
assert run["source_commit"]=="98126f898412f675ebdd406c35cd273f4972dd2b"
assert run["source_diff_sha256"]=="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
assert run["settings"]["storage"]["prefetch_buffer_capacity_mb"]==4096
scheduler=run["settings"]["storage"]["object_store"]["read_scheduler"]
for key,expected in dict(max_gap_bytes=gap,max_read_bytes=1048576,max_admitted_groups=128,max_inflight_reads=32,dedicated_io_runtime_workers=6,max_batch_requests=16).items():
    assert scheduler[key]==expected,(key,expected)
assert run["actual_runtime_workers_before"]=={"rw-read-io":6,"rw-streaming":8,"rw-batch":12,"rw-compaction":4}
first,last=(metrics((arm/f).read_bytes()) for f in ("before.prom","after.prom"))
source=json.loads((arm/"source-checkpoint.json").read_text())
timeline={0:first,run["phase"]["whole"]["wall_time_s"]:last,source["elapsed_s"]:parse_lines(source["metrics"])}
for file in ("samples.jsonl.gz","source-samples.jsonl.gz"):
    with gzip.open(arm/file,"rt") as f:
        timeline.update((t,parse_lines(raw)) for t,_,raw in map(json.loads,f))
startup=[]
for t0,t1,lines,*rest in map(json.loads,(arm/"startup-samples.jsonl").open()):
    if isinstance(lines,list):
        startup.append((t0,parse_lines(lines)))

prefetch="state_store_cold_range_prefetch_"
for name,p in run["phase"].items():
    begin,end=p["elapsed_scrape_bounds_s"]
    a,b=(timeline[t] for t in (begin,end))
    def count(metric,**labels):
        return int(delta(a,b,metric,**labels))
    p["latency_ms"]["all_object_reads"]=export.latency(a,b,"object_store_read_request_duration_seconds",{})
    p["cold_range_prefetch"]={key:export.read_hist(a,b,prefetch+key,{},thresholds=thresholds)
        for key,thresholds in (("window_runs",(0,1)),("read_bytes",(4096,16384,65536)),("gap_bytes",(4096,16384,65536)),("gap_blocks",(1,)))}
    p["prefetch_budget_counters"]={key:count(prefetch+key) for key in ("budget_denied","budget_shrunk","single_blocks","hint_misses")}
    p["prefetch_and_misses_by_table"]={tab:{key:count("state_store_sst_store_block_request_counts",table_id=tab,type=key)
        for key in ("prefetch_count","prefetch_data_count","data_miss","meta_miss")}
        for tab in ("6","11","16","28","34","40","47","50","54","32","38")}
    p["logical_bounded_requested_bytes"]={route:{"count":count("object_store_read_request_bytes_count",route=route),
        "bytes":count("object_store_read_request_bytes_sum",route=route)}
        for route in ("scheduled","oversized","direct","empty_range")}
    p["all_scheduler_events"]={dict(labels)["event"]:count("object_store_read_scheduler_events",event=dict(labels)["event"])
        for (metric,labels) in b if metric=="object_store_read_scheduler_events"}
    p["ordinary_block_cache_events"]={event:count("state_store_block_cache_read_events",event=event)
        for event in ("outer_fetch","pending","memory_hit")}
    p["overlap_observations"]={"partial_dispatch":count("object_store_read_scheduler_events",event="partial_overlap_dispatch"),
        "partial_bytes":count("object_store_read_scheduler_partial_overlap_bytes"),
        "buffered":{policy:{k:count("state_store_cold_range_buffered_overlap_"+k,cache_policy=policy)
            for k in ("reads","bytes")} for policy in ("fill","not_fill","disable")}}
    p["object_store_read_outcomes"]={stage:{outcome:count("object_store_read_outcomes",stage=stage,outcome=outcome)
        for outcome in ("ok","error","cancelled")} for stage in ("logical","physical","attempt")}
    assert not any(p["object_store_read_outcomes"][stage]["error"] for stage in ("logical","physical","attempt"))
    p["prefetch_buffer_sampled_peak_bytes"]=max(
        (value for t,snapshot in [*timeline.items(),*startup] if begin<=t<=end
         for (metric,_),value in snapshot.items() if metric=="state_store_prefetch_memory_size"),default=0)
    p["cn_rss_sampled_peak_bytes"]=max(
        (value for t,snapshot in [*timeline.items(),*startup] if begin<=t<=end
         for (metric,_),value in snapshot.items() if metric=="process_resident_memory_bytes"),default=0)

whole=run["phase"]["whole"]
assert whole["gets"]==whole["object_store_read_outcomes"]["physical"]["ok"]
assert whole["latency_ms"]["all_object_reads"]["sample_count"]==sum(whole["object_store_read_outcomes"]["logical"].values())
assert run["oracle_rows"]==100 and run["oracle_matches"]
curve=[]
gauge_samples=[]
for at,finished,lines in map(json.loads,(arm/"congestion.jsonl").open()):
    if isinstance(lines,list):
        gauge_samples.append((at,parse_lines(lines)))
for t,snapshot in sorted([*timeline.items(),*startup,*gauge_samples],key=lambda sample:sample[0]):
    def value(metric):
        return sum(v for (m,_),v in snapshot.items() if m==metric)
    curve.append(dict(elapsed_s=t,prefetch_bytes=value("state_store_prefetch_memory_size"),
        cn_rss_bytes=value("process_resident_memory_bytes"),
        budget_denied=value(prefetch+"budget_denied"),budget_shrunk=value(prefetch+"budget_shrunk"),
        source_rows=sum(v for (m,labels),v in snapshot.items() if m=="stream_snapshot_backfill_consume_snapshot_row_count"
                        and ("stage","consuming_snapshot") in labels)))
for phase in run["phase"].values():
    lo,hi=phase["elapsed_scrape_bounds_s"]
    points=[point for point in curve if lo<=point["elapsed_s"]<=hi]
    phase["prefetch_buffer_sampled_peak_bytes"]=max(point["prefetch_bytes"] for point in points)
    phase["cn_rss_sampled_peak_bytes"]=max(point["cn_rss_bytes"] for point in points)
run["peak_cn_rss_mib"]=run["phase"]["whole"]["cn_rss_sampled_peak_bytes"]/2**20
(arm/"memory-curve.json").write_text(json.dumps(curve,separators=(",",":"))+"\n")
run["arm"]=arm.name
run["source_checkpoint_sampling"]="first full 1 s source scrape; 0.1 s during startup"
run["source_checkpoint_after_first_provider_s"]=run["source_checkpoint_s"]-run["operator_milestones_s"]["first_provider"]
(arm/"matrix-analysis.json").write_text(json.dumps(run,indent=2,allow_nan=False)+"\n")
print(json.dumps(dict(arm=arm.name,wall_s=whole["wall_time_s"],gets=whole["gets"],
    source_checkpoint_s=run["source_checkpoint_s"],source_gets=run["phase"]["through_source"]["gets"],
    source_budget=run["phase"]["through_source"]["prefetch_budget_counters"],rss_mib=run["peak_cn_rss_mib"])))

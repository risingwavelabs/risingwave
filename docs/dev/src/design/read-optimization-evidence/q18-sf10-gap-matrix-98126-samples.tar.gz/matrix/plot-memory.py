"""Plot the retained source-stage memory curves after the benchmark matrix."""
from pathlib import Path
import json

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

suite=Path(__file__).resolve().parent
order=['p1-gap0','p1-gap64k','p2-gap0','p2-gap64k','p3-gap0','p3-gap64k']
fig,axes=plt.subplots(3,2,figsize=(12,10),sharex=True,sharey=True)
for axis,name in zip(axes.flat,order):
    arm=suite/name
    stats=json.loads((arm/'matrix-analysis.json').read_text())
    cutoff=stats['source_checkpoint_s']
    points=json.loads((arm/'memory-curve.json').read_text())
    points=[p for p in points if p['elapsed_s']<=cutoff+2]
    # Prefer the last sample at an identical timestamp rather than connecting duplicate points.
    points=sorted({p['elapsed_s']:p for p in points}.values(),key=lambda p:p['elapsed_s'])
    elapsed=[p['elapsed_s'] for p in points]
    axis.plot(elapsed,[p['prefetch_bytes']/2**30 for p in points],label='Prefetch charge',color='#2358a6',linewidth=1.7)
    axis.plot(elapsed,[p['cn_rss_bytes']/2**30 for p in points],label='CN RSS',color='#217a55',linewidth=1.5)
    axis.axhline(4,label='4 GiB budget',color='#9a4c0b',linestyle='--',linewidth=1)
    axis.axvline(cutoff,label='Source checkpoint',color='#777777',linestyle=':',linewidth=1)
    budget=stats['phase']['through_source']['prefetch_budget_counters']
    gap='64 KiB' if '-gap64k' in name else '0'
    axis.set_title(f'Pair {stats["round"]}  /  gap {gap}  /  denied {budget["budget_denied"]}, shrunk {budget["budget_shrunk"]}',fontsize=10)
    axis.grid(alpha=.2)
    axis.set_ylim(0,7)
    axis.set_xlim(left=0)
max_cutoff=max(json.loads((suite/name/'matrix-analysis.json').read_text())['source_checkpoint_s'] for name in order)
for axis in axes.flat:axis.set_xlim(0,max_cutoff+2)
for axis in axes[-1]:axis.set_xlabel('Seconds since CREATE MV')
for axis in axes[:,0]:axis.set_ylabel('GiB')
handles,labels=axes[0,0].get_legend_handles_labels()
fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.53,.965),ncol=4,frameon=False)
fig.suptitle('SF10 Q18 source-stage memory / 98126f8984 / six I/O workers',fontsize=13,y=.995)
fig.subplots_adjust(left=.065,right=.99,bottom=.065,top=.90,hspace=.30,wspace=.04)
fig.savefig(suite/'source-memory-curves.png',dpi=180)
print(suite/'source-memory-curves.png')
